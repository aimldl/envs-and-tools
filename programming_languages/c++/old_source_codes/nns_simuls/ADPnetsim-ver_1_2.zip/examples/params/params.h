
#ifndef PARAMS_H
#define PARAMS_H

#include <iostream>
#include <stdio.h>

using namespace std;

class parameter_list;

class parameter{
private:
protected:
  int type;
  char *tag;
  char *desc;
  parameter *next;
public:
  parameter(){next = NULL;};
            
  void set_next(parameter *Next)
    {next = Next;};  
  parameter *get_next()
    {return next;};  

  char *get_tag(){return tag;};
  int param_type(){return type;};

  virtual int set_value(char *val)
    {cerr << "no set_value function for "<<type<<"\n";return 0;};

  virtual void print(ostream &o)
    {o<<"no print function defined\n";};

  void usage(ostream &o);

};

class integer_parameter:public parameter{
private:
  int my_value;
public:
  integer_parameter(parameter_list &p,char *Tag, int default_value, char *description);
  ~integer_parameter();
  int value(){return my_value;};
  int set_value(char *val)
  {
    if(sscanf(val,"%d",&my_value)!=1)
      return 1;
    return 0;
  };
  void print(ostream &o);
};

class double_parameter:public parameter{
private:
  double my_value;
public:
  double_parameter(parameter_list &p,char *Tag, double default_value, char *description);
  ~double_parameter();
  double value(){return my_value;};
  int set_value(char *val)
  {
    if(sscanf(val,"%lf",&my_value)!=1)
      return 1;
    return 0;
  };
  void print(ostream &o);
};

class boolean_parameter:public parameter{
private:
  int my_value;
public:
  boolean_parameter(parameter_list &p,char *Tag, int default_value, char *description);
  ~boolean_parameter();
  int value(){return my_value;};
  int set_value(char *val)
  {
    my_value = !my_value;
    return 0;
  };
  void print(ostream &o);
};

class string_parameter:public parameter{
private:
  char *my_value;
public:
  string_parameter(parameter_list &p,char *Tag, char *default_value, char *description);
  ~string_parameter();
  char *value(){return my_value;};
  int set_value(char *val)
  {
    my_value = val;
    return 0;
  };
  void print(ostream &o);
};




class parameter_list{
private:
  parameter *parameters;

public:
  parameter_list(){parameters = NULL;};
  ~parameter_list(){};

  void add_parameter(parameter *p)
    {
      p->set_next(parameters);
      parameters = p;
    }

  void delete_parameter(parameter *p){};

  int parse(int argc, char **argv);

  void print(ostream &o);

  void usage(ostream &o,char **argv);

};


#endif
