

#include "params.h"
#include <string.h>
#define P_INTEGER 0
#define P_STRING  1
#define P_BOOLEAN 2
#define P_DOUBLE  3

char *type_strings[]={
  "integer","string ","boolean","float  "
};

static char *typestr(int type)
{
  return type_strings[type];
}

void parameter::usage(ostream &o)   
{
  o.width(10);
  o<<tag;
  o<<" "<<typestr(type)<<" "<<desc<<"\n";
}




integer_parameter::integer_parameter(parameter_list &p,char *Tag, int default_value, char *description)
{ 
  type = P_INTEGER;
  tag=Tag; 
  my_value=default_value; 
  desc=description;
  p.add_parameter(this);
}

integer_parameter::~integer_parameter()
{}

void integer_parameter::print(ostream &o)
{
  o.width(10);
  o<<tag;
  o<<" "<<typestr(type)<<" "<< my_value<<"\n";
};


double_parameter::double_parameter(parameter_list &p,char *Tag, double default_value, char *description)
{ 
  type = P_DOUBLE;
  tag=Tag; 
  my_value=default_value; 
  desc=description;
  p.add_parameter(this);
}

double_parameter::~double_parameter()
{}

void double_parameter::print(ostream &o)
{
  o.width(10);
  o<<tag;
  o<<" "<<typestr(type)<<" "<< my_value<<"\n";
};


boolean_parameter::boolean_parameter(parameter_list &p,char *Tag, int default_value, char *description)
{ 
  type = P_BOOLEAN;
  tag=Tag; 
  my_value=default_value; 
  desc=description;
  p.add_parameter(this);
}

boolean_parameter::~boolean_parameter()
{}

void boolean_parameter::print(ostream &o)
{
  o.width(10);
  o<<tag;
  o<<" "<<typestr(type)<<" ";
  if(my_value)
    o<<"True\n";
  else
    o<<"False\n";
};

string_parameter::string_parameter(parameter_list &p,char *Tag, char *default_value, char *description)
{ 
  type = P_STRING;
  tag=Tag; 
  my_value=default_value; 
  desc=description;
  p.add_parameter(this);
}
string_parameter::~string_parameter()
{}

void string_parameter::print(ostream &o)
{
  o.width(10);
  o<<tag;
  o<<" "<<typestr(type)<<" "<<my_value<<"\n";
};

int parameter_list::parse(int argc, char **argv)
 { 
   int i;
   parameter *p;

   for(i=1;i<argc;i++)
     {
       for(p=parameters;
             (p!=NULL)&&(strcmp(p->get_tag(),argv[i]));
             p=p->get_next());
       if(p==NULL)
         return 1;
       switch(p->param_type())
         {
         case P_BOOLEAN:
           p->set_value(argv[i]);
           break;
         case P_INTEGER:
         case P_STRING:
         case P_DOUBLE:
           if(++i==argc)
             return 1;
           p->set_value(argv[i]);
           break;
         default:
           cerr<<"unknown parameter type "<<p->param_type()<<"\n";
         }
     }
   return 0;
 }

void parameter_list::usage(ostream &o,char **argv)
{
  parameter *p;
  cout<<"\nUSAGE: "<<argv[0]<<" <parameters>\n\n";
  o<<"Parameter  Type    Description\n";
  for(p=parameters;p!=NULL;p=p->get_next())
   p->usage(o);
}


void parameter_list::print(ostream &o)
{
  parameter *p;
  o<<"Program Parameters:\n"<<"Parameter  Type    Value\n";
  for(p=parameters;p!=NULL;p=p->get_next())
   p->print(o);
}





