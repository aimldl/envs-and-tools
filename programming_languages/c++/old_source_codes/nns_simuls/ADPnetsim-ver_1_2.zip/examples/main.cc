// -*- Mode: C++ -*-

#include <iostream>
#include <fstream>
#include <sim_object.h>
#include <packet.h>
#include <event.h>
#include <scheduler.h>
#include <link.h>
#include <node.h>
#include <math.h>
#include <data_agent.h>
#include <trace.h>
#include <params.h>

#define MESHSIZE 5
#define NUM_AGENTS 100

#define DELAY 0.01
#define DR 10000000.0

// start the data agents after 30 seconds to give time for
// routing agents to get some routing data propagated
#define START_TIME  30.0
#define STOP_TIME 400.0

// give a few seconds for data packets to get to their destination
#define SIM_END_TIME 410

#define PACKET_SIZE 2000
#define PKT_PER_SEC 15
#define PACKET_TTL  100

#define QUEUE_SIZE 100

#define MIN_DIST 5

int distance(int x1,int y1,int x2,int y2)
{
  return abs(x1-x2) + abs(y1-y2);
}

int main(int argc,char **argv)
{
  int i,j,k;


  // PROCESS the command line parameters
  parameter_list p;
  boolean_parameter cdcp(p,"-cdc",0,"Change duty cycle during run");
  boolean_parameter nolearn(p,"-nolearn",0,"Turn off learning");
  string_parameter ofilename(p,"-of","",
			    "File to print messages to default is stdout");
  boolean_parameter shortpathp(p,"-shortpath",0,
			       "Enable shortest path (Link-State) routing");
  boolean_parameter gossipp(p,"-gossip",0,
			    "Enable Gossip routing");
  boolean_parameter floodp(p,"-flooding",0,"Enable flooding ");
  // default duty cycle of 1.0 means links never go down.
  double_parameter dcp(p,"-dc",1.0,"Duty Cycle of links");
  double_parameter ctp(p,"-ct",10.0,"Cycle time for links");
  boolean_parameter verbp(p,"-v",0,"Be verbose");
  boolean_parameter shortp(p,"-short",0,"Output only the % received");
  boolean_parameter helpp(p,"-h",0,"Print help and exit");
  p.parse(argc,argv);

  ofstream outfile;

  if(ofilename.value() != "")
    {
      streambuf *ofsb;
      outfile.open(ofilename.value(),ofstream::out);
      ofsb = outfile.rdbuf();
      cout.rdbuf(ofsb);
    }


  if(verbp.value())
    {
      p.print(cout);
      exit(0);
    }


  if(helpp.value())
    {
      p.usage(cout,argv);
      exit(0);
    }
  double DUTY_CYCLE = dcp.value();
  double CYCLE_TIME = ctp.value();

  // INITIALIZE the random number generators
  time_t tm;
  srandom(8705321);
  srand48(8705321);
  srandom(time(&tm));
  srand48(time(&tm));


  // SET the trace files for our format and for NAM format
  // trace.tracefile("netsim.trace");
  // trace.namfile("netsim.nam");  


  //i = shortpathp.value() + gossipp.value() + floodp.value();
  //if(i>1)
  //{
  //  cerr<<"Sorry, right now you can only use ONE of the routing strategies\n";
  //  exit(1);
  //}

  // TELL routing agent which strategies are enabled
  routing_agent::set_strategy(SHORTEST_PATH_STRATEGY,shortpathp.value());
  routing_agent::set_strategy(GOSSIP_STRATEGY,gossipp.value());
  routing_agent::set_strategy(FLOOD_STRATEGY,floodp.value());

  // DECLARE the nodes, links, traffic sources, and traffic sinks
  node *nodes[MESHSIZE][MESHSIZE];
  duplex_link *links[2][(MESHSIZE)][(MESHSIZE)];
  traffic_source *sources[NUM_AGENTS];
  traffic_sink *sinks[NUM_AGENTS];

  // Create Nodes
  for(i=0;i<MESHSIZE;i++)
    for(j=0;j<MESHSIZE;j++)      
      {
	nodes[i][j] = new node;
	if(nolearn.value())
	  nodes[i][j]->learn(0);
      }

  // Create Links
  for(i=0;i<MESHSIZE-1;i++)
    for(j=0;j<MESHSIZE;j++)
      {
	links[0][i][j] = new duplex_link(nodes[i][j],nodes[i+1][j],DELAY,DR);
	links[0][i][j]->set_dynamics(DUTY_CYCLE,CYCLE_TIME);
	links[0][i][j]->set_queue_size(QUEUE_SIZE);
	links[0][i][j]->set_orientation("down");
      }

  for(i=0;i<MESHSIZE;i++)
    for(j=0;j<MESHSIZE-1;j++)
      {
	links[1][i][j] = new duplex_link(nodes[i][j],nodes[i][j+1],DELAY,DR);
	links[1][i][j]->set_dynamics(DUTY_CYCLE,CYCLE_TIME);
	links[1][i][j]->set_queue_size(QUEUE_SIZE);
	links[1][i][j]->set_orientation("right");
      }

  // create the sources and sinks
  for(i=0;i<NUM_AGENTS;i++)
    {
      sources[i] = new traffic_source;
      sinks[i] = new traffic_sink;

      // assign sources and sinks to random nodes, but make
      // sure they are at least MIN_DIST hops apart
      int sx,sy,dx,dy;
      do
	{
	  sx = random() % MESHSIZE;
	  sy = random() % MESHSIZE;
	  dx = random() % MESHSIZE;
	  dy = random() % MESHSIZE;
	}
      while(distance(sx,sy,dx,dy)<MIN_DIST);

      //cout<<"sender at ("<<sx<<","<<sy<<
      //  ") Receiver at ("<<dx<<","<<dy<<")\n";

      sources[i]->set_node(nodes[sx][sy]);
      sinks[i]->set_node(nodes[dx][dy]);
     
      sources[i]->attach(sinks[i]);
      sinks[i]->attach(sources[i]);

      // Set the TTL for each packet
      sources[i]->set_ttl(PACKET_TTL);

      // Set size of each packet
      sources[i]->set_pkt_size(PACKET_SIZE);

      // send out a packets at this rate
      sources[i]->set_rate(PKT_PER_SEC);

      // start sending packets at START_TIME
      sources[i]->start_at(START_TIME);

      sources[i]->stop_at(STOP_TIME);

    }

  // dump the objects
  //sim_object::dump_objects();

  // call the start methods for all sim_objects that have been created
  sim_object::start_objects();

  // set the stop time for the simulation
  Scheduler.stop_at(SIM_END_TIME);

  // Start the simulation... Handle events while they exist,
  // or until time runs out

#define REPORT_INTERVAL 10.0
  double next_report = REPORT_INTERVAL;

#define LINK_CHANGE_INTERVAL 10.0
  double next_link_change = LINK_CHANGE_INTERVAL*4;

#define INITIAL_DC_INC 0.05
  double DC_INC = INITIAL_DC_INC;
  double  curr_duty_cycle = DUTY_CYCLE;

  while(Scheduler.dispatch())
    {
      if(Scheduler.time()>next_report)
	{
	  if(!shortp.value())
	    cout<<"Time now "<<next_report<<endl;
	  next_report += REPORT_INTERVAL;	  
	}
      if(cdcp.value() && (Scheduler.time()>next_link_change))
	{
	  if(((curr_duty_cycle-DC_INC) < 0.05)||((curr_duty_cycle-DC_INC) > 1))
	    DC_INC = -DC_INC;
	  curr_duty_cycle = curr_duty_cycle - DC_INC;
	  if(!shortp.value())
	    cout<<"changing duty cycle to "<<curr_duty_cycle<<endl;
	  // Change Links
	  for(i=0;i<MESHSIZE-1;i++)
	    for(j=0;j<MESHSIZE;j++)
	      links[0][i][j]->set_dynamics(curr_duty_cycle,CYCLE_TIME);
	  
	  for(i=0;i<MESHSIZE;i++)
	    for(j=0;j<MESHSIZE-1;j++)
	      links[1][i][j]->set_dynamics(curr_duty_cycle,CYCLE_TIME);
	  
	  next_link_change += LINK_CHANGE_INTERVAL;
	}
      
    };
  

  // count up all of our packets sent and received
  int sent = 0;
  int received = 0;
  for(i=0;i<NUM_AGENTS;i++)
    {
      sent += sources[i]->packet_count();
      received += sinks[i]->packet_count();
    }

  if(!shortp.value())
    {
      cout<<sent<<" packets were sent. "<<received<<" of them ("<<
	(100.0 * received) / sent<<"%) were received.\n";
      //cout<<"Result: "<<DUTY_CYCLE<<" "<<(100.0 * received) / sent<<endl;
    }
  else
    cout<<(100.0 * received) / sent<<endl;
    

  // dump the objects
  //sim_object::dump_objects();

  int queue_count = 0;
  int wire_count = 0;
  // Count packets in send queues and on wires (some could be control packets)
  for(i=0;i<MESHSIZE-1;i++)
    for(j=0;j<MESHSIZE;j++)
      {
	queue_count += links[0][i][j]->get_queue_count();
	wire_count += links[0][i][j]->get_wire_count();
      }

  for(i=0;i<MESHSIZE;i++)
    for(j=0;j<MESHSIZE-1;j++)
      {
	queue_count += links[1][i][j]->get_queue_count();
	wire_count += links[1][i][j]->get_wire_count();
      }
  
  if(!shortp.value())
    {
      cout<<"There are "<<queue_count<<" packets in the packet queues\n";
      cout<<"There are "<<wire_count<<" packets on the links\n";
      Scheduler.report();
    }

  // delete everything...
  sim_object::deleteall();
  Scheduler.flush();

  return 0;
}
