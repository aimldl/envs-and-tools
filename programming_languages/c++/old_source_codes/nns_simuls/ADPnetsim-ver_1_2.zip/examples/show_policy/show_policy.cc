
#include <policy.h>



int main(int argc,char **argv)
{
  if(argc != 2)
    {
      cout<<"Usage :"<<argv[0]<<" <filename>\n";
      exit(1);
    }

  table_policy t(1,1);
  t.restore(argv[1]);
  t.print();
  return 0;
}
