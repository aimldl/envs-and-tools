// This is an awful hack!  It sets up a list of jobs in an array,
// then splits into threads.  Each thread takes the next job and
// uses fork/exec to run netsim.  After the exec, it gets the results
// and adds them to the sums it has.  After all jobs finish, the
// threads rejoin and the main finishes processing the results.
// I used lots of globals and other bad things.  There really isn't
// any reason to use threads.

#include <pthread.h>
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

// how many netsim processes do you want to run?
#define NUM_THREADS 1

#define NUM_SAMPLES 10

char *duty_cycles[]={ "0.05",
		      "0.1",
		      "0.15",
		      "0.2",
		      "0.25",
		      "0.3",
		      "0.35",
		      "0.4",
		      "0.45",
		      "0.5",
		      "0.55",
		      "0.6",
		      "0.65",
		      "0.7",
		      "0.75",
		      "0.8",
		      "0.85",
		      "0.9",
		      "0.95",
		      "1.0"};
#define NUM_DC 20

char *protocols[]= { "-gossip",
		     "-shortpath"};
#define GOSSIP 0
#define LINKSTATE 1
#define NUM_PROT 2



typedef struct{
  int routing_protocol;  // GOSSIP or LINKSTATE
  int duty_cycle;        // index to one of duty_cycles
}job;


pthread_mutex_t job_mutex;
int currjob;

pthread_mutex_t sum_mutex;

double sums[NUM_PROT][NUM_DC];

// find out how many jobs we have to run
int numjobs;
job * jobs;

char *netsim;

extern "C" void * job_thread(void *nothing)
{
  pid_t pid,npid;
  int status;
  int mycurrjob;
  char filename[100];
  pthread_mutex_lock(&(job_mutex));
  mycurrjob = currjob++;
  pthread_mutex_unlock(&(job_mutex));
  while(mycurrjob < numjobs)
    {
      sprintf(filename,"output%s.%d",
	      protocols[jobs[mycurrjob].routing_protocol],mycurrjob);
      // fork and exec to run my current job
      if((pid = fork()) == 0)
	{
	  // child
	  execl(netsim,"netsim",
		protocols[jobs[mycurrjob].routing_protocol],
		"-dc",
		duty_cycles[jobs[mycurrjob].duty_cycle],
		"-of",filename,"-short",NULL);
		
	  printf("job number %d has completed\n",mycurrjob);
	  
	  // cout<<mycurrjob<<endl;
	  exit(0);
	}
      else
	{
	  if(pid < 0)
	    {
	      perror("unable to create child process\n");
	      exit(1);
	    }
	  // when our particular child exits, get the results and add
	  // to the correct sum
	  npid = waitpid(pid,&status,0);
	  if(npid != pid)
	    {
	      fprintf(stderr,"wait for child %d got child %d\n",pid,npid);
	      fprintf(stderr,"child %d status was %d\n",npid,status);
	      exit(1);
	    }

	  // Child has exited.  Get the results by reading the file
	  // and add to the appropriate sum.
	  FILE *rf; 
	  double result;
	  if((rf = fopen(filename,"r")) == NULL)
	    {
	      perror("error getting results\n");
	      exit(1);
	    }
	  if(fscanf(rf,"%lf",&result) != 1)
	    {
	      perror("error getting results\n");
	      exit(1);
	    }
	  fclose(rf);
	  //unlink(filename);
	  pthread_mutex_lock(&(sum_mutex));
	  sums[jobs[mycurrjob].routing_protocol][jobs[mycurrjob].duty_cycle] += 
	    result;
	  pthread_mutex_unlock(&(sum_mutex));
	}
      pthread_mutex_lock(&(job_mutex));
      mycurrjob = currjob++;
      pthread_mutex_unlock(&(job_mutex));
    }
  pthread_exit(0);
  return 0;

}

// It may be better create a simulator class to hold the
// static members of all the classes, then
// do ALL of this with threads.  Having threads spawn child
// processes may also have advantages.  I don't know, but that
// is what I'm doing.
int main()
{
  int i,j,k;

  // look in cwd

  char *tmp1= new char[200];
  netsim= new char[200];

  // we expect netsim to be in the current directory
  getcwd(tmp1,100);
  sprintf(netsim,"%s/netsim",tmp1);

  for(i=0;i<NUM_PROT;i++)
    for(j=0;j<NUM_DC;j++)
      sums[i][j]=0.0;

  // find out how many jobs we have to run
  numjobs = NUM_SAMPLES * NUM_DC * NUM_PROT;
  jobs = new job[numjobs];
  
  // set up a list of job descriptors
  currjob = 0;
  for(i=0;i<NUM_SAMPLES;i++)
    for(j=0;j<NUM_DC;j++)
      for(k=0;k<NUM_PROT;k++)
	{
	  jobs[currjob].routing_protocol = k;
	  jobs[currjob].duty_cycle = j;
	  currjob++;
	}
  currjob = 0;

  // Create some threads.  Each thread will take a job from
  // the list and run it.  The threads will join when there
  // are no more jobs.

  pthread_t *thread = new pthread_t[NUM_THREADS];
  pthread_mutex_init(&(job_mutex),NULL);
  pthread_mutex_init(&(sum_mutex),NULL);

  for(j=0;j<NUM_THREADS;j++)
    {
      pthread_create(&(thread[j]),NULL,job_thread,NULL);
      sleep(2);
    }
  
  for(j=0;j<NUM_THREADS;j++)
    pthread_join(thread[j],NULL);
  
  delete[] thread;

  // now the sums should be calculated, just have to divide
  // by NUM_SAMPLES and print the results


  for(i=0;i<NUM_PROT;i++)
    for(j=0;j<NUM_DC;j++)
      sums[i][j] /= NUM_SAMPLES;

  
  for(i=0;i<NUM_PROT;i++)
    {
      FILE *of;
      char filename[100];
      sprintf(filename,"results%s",protocols[i]);
      of=fopen(filename,"w");
      for(j=0;j<NUM_DC;j++)
	fprintf(of,"%s %lf\n",duty_cycles[j],sums[i][j]);
      fclose(of);
    }


  return 0;
}
