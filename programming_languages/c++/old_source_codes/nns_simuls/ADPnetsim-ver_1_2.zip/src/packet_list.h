// -*- Mode: C++ -*-

#ifndef PACKET_LIST_H
#define PACKET_LIST_H

#include <iostream>
#include <string>

#include <packet.h>

using namespace std;

typedef struct{
  // variables that make up the state space
  int haveroute;
  double sctime;
  double actime;
}state_desc;


typedef struct{
  packet_header h;
  // the following is used for learning if we get an ack for this packet
  //  state_desc state;
  int ACK_received;
  int state;
  int action;
  double ctime;
}packet_rec;



class packet_list{
 private:
  packet_rec *data;
  packet_list *next;
public:

  typedef struct{
    packet_list *head;
    packet_list *tail;
    int num_recs;
  }head_tail;

  packet_list()
  {
    data = NULL;
    next = NULL;
  }

  ~packet_list()
  {
    if(data != NULL) 
      delete data;
  }
  
  void set_next(packet_list *n);
  packet_list *get_next();

  packet_rec *get_data();
  void set_data(packet_rec *d);

};


// a linked list implementation for storing and retrieving packet records
class packet_DB_ll{
private:
  packet_list *l;
  int rec_count;
 public:

  packet_DB_ll();

  ~packet_DB_ll();

  // get record for adjacency from source to dest
  packet_rec *get(packet_header *h);

  // insert a new record into the database (or replace an existing record)
  void add(packet_rec *r);

  // remove all packets older than ltime from the list and return
  // a pointer to them
  packet_list::head_tail *purge(double ltime);

  int num_records(){return rec_count;}

  packet_list *get_list(){return l;}

};

// a hash table implementation for storing and retrieving packet
// records.  Each entry in the hash table is a packet_DB_ll, so
// collisions are handled by adding the colliding packet records 
// to the linked list.
class packet_DB{
 public:

  packet_DB();

  ~packet_DB();

  // get record for adjacency from source to dest
  packet_rec *get(packet_header *h);

  // insert a new record into the database (or replace an existing record)
  void add(packet_rec *r);

  // remove a record from the database
  // void remove(packet_list *r);  // Not implemented

  // remove all packets older than ltime from the list and return
  // a pointer to them
  
  packet_list::head_tail *purge(double ltime);
  
 private:
  void grow_table();
  packet_DB_ll *table;  // an array of packet_DB_ll linked lists
  int table_size;
  int num_bits;
  int get_hash_key(packet_header *h);
  void hash_stats();
  int add_count;
};

#endif
