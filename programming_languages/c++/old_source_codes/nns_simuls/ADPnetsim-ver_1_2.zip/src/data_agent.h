// -*- Mode: C++ -*-

#ifndef DATA_AGENT_H
#define DATA_AGENT_H

#include <sim_object.h>
#include <node.h>
#include <packet.h>
#include <event.h>

/// This is the base class for agents that send and receive data.
///
/// Communication in the simulator is simulated by data agents, which
/// inject data packets into the network or remove data packets from it.
/// Data agents come in two flavors: traffic sources and traffic sinks.
/// We assume that sources and sinks exist in pairs, and generally
/// live on differnt nodes.
class data_agent:public sim_object{
private:
  int portnum;  ///< The port that this data agent is attached to
  node *Node;   ///< The node that this data agent runs on.
  data_agent *other;  ///< The other data_agent in this source/sink pair.
protected:
  unsigned int seqnum; ///< Sequence number for next packet.
  packet_header *make_header(); ///< Create a header for a packet.
  int packet_ttl;          ///< TTL assigned to our packets.
public:
  data_agent();
  virtual ~data_agent();

  virtual void dump();   ///< Print information on cout.

  virtual void start();  ///< Prepare to start the simulation.

  void set_ttl(int ttl); ///< Set the TTL for packets.

  virtual void handle(event *e);  ///< Handle an event.

  /// Connect this data_agent to its counterpart.
  void attach(data_agent *other_end);  

  /// Set the port that this data_agent is on.
  void set_port(int port);
  /// Get the port that this data_agent is on.
  int get_port();

  /// Assign this data_agent to a node.
  void set_node(node *n);
  /// Find the node that this data_agent is running on.
  node* get_node();

  /// Get the address of the node and port that this data agent is running on.
  addr_t get_address();

  /// Find out how many packets this data agent has sent or recieved.
  int packet_count(){return seqnum;}

};


/// data_agent that injects packets into the network.
///
/// A traffic source creates packets and hands them to the local
/// routing agent.  The routing agent tries to get the packet to 
/// it's destination.
class traffic_source:public data_agent{
private:
  /// Time in seconds from beginning of simulation when packet
  /// generation begins
  double start_time;  

  /// Time in seconds from beginning of simulation when packet
  /// generation ends
  double stop_time;

  int packet_size;    ///< Size of packets in bytes.
  double packet_rate; ///< Rate that packets are generated in packets/sec.

  void process_message(message_event *e);

  void traffic_source::send_packet();
public:
  traffic_source();
  virtual ~traffic_source();

  /// Set the size of packets in bytes.
  void set_pkt_size(int size);  

  /// Set packet generation rate in packets/second.
  void set_rate(double pkts_per_sec);  

  /// Set the time in seconds from the beginning of simulation when
  /// packet generation should start.
  void start_at(double tm);

  /// Set the time in seconds from the beginning of simulation when
  /// packet generation should stop.
  void stop_at(double tm);

  /// Print information to cout.
  virtual void dump();

  /// Prepare to begin simulation.
  virtual void start();

  /// Handle an event.
  virtual void handle(event *e);

};


class traffic_sink:public data_agent{
public:
  /// Print information to cout.
  virtual void dump();

  /// Prepare to begin simulation.
  virtual void start();

  /// Handle an event.
  virtual void handle(event *e);
};

#endif
