// -*- Mode: C++ -*-


#include <sim_object.h>

/// Static integer used to assign the unique ID for sim_objects.
int sim_object::last_ID = 0;

/// Static linked list of sim_objects.
sim_object *sim_object::sim_objects=NULL;

sim_object::sim_object()
{
  ID=last_ID++;
  next = sim_objects;
  sim_objects = this;
}

sim_object::~sim_object()
{
  //cout<<"sim_object destructor called\n";
}


void sim_object::start()
{
};

void sim_object::handle(event *e)
{
  cout<<"No handle method defined\n";exit(1);
}

int sim_object::get_ID()
{
  return ID;
}







void sim_object::dump()
{
  printf("object ID=%d\n",ID);
}

void sim_object::dump_objects()
{
  sim_object *obj=sim_objects;
  while(obj != NULL)
    {
      obj->dump();
      obj=obj->next;
    }
}

void sim_object::start_objects()
{
  sim_object *obj=sim_objects;
  while(obj != NULL)
    {
      obj->start();
      obj=obj->next;
    }
}

void sim_object::deleteall()
{
  sim_object *obj=sim_objects;
  while(obj != NULL)
    {
      sim_objects = obj->next;
      delete obj;
      obj = sim_objects;
    }
}
