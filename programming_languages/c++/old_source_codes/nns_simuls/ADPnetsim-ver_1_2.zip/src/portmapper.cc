// -*- Mode: C++ -*-

#include <sim_object.h>
#include <event.h>
#include <portmapper.h>

portmapper::portmapper()
{
  ports = NULL;
  numports =0;
}

portmapper::~portmapper()
{
  if(ports != NULL)
    delete[] ports;
}


// give the object a port and return the port number
int portmapper::add(sim_object *obj)
{
  int i;
  sim_object **nports;
  nports = new sim_object*[++numports];
  for(i=0;i<numports-1;i++)
    nports[i] = ports[i];
  nports[numports-1] = obj;
  delete[] ports;
  ports = nports;
  return numports-1;      
}

// the event should aways be a packet_event, but who cares?
void portmapper::handle(event *e)
{
  packet_event *pe;
  packet_header *h;
  int dport;
  switch(e->type())
    {
    case event::packet:
      pe = (packet_event *)e;
      h = pe->get_packet()->get_header();
      dport = h->dst_port;
      if(dport >= numports)
	{
	  cerr<<"packet received on invalid port\n";
	  exit(1);
	}
      ports[dport]->handle(e);
      break;
    default:
      cerr<<"portmapper got weird event type\n";
      exit(1);
      break;
    }
}
