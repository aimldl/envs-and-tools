// -*- Mode: C++ -*-
//
// Netsim - a network simulator
// Written by Larry D. Pyeatt
// Copyright 2005
// All rights reserved
//
// akb.h - Header file for the Adjacency Knowledge Base (AKB)
// Each node in the network has an AKB to store information
// about the network and its links.  The AKB is basically a
// simple database, plus some algorithms for finding routes.

#ifndef AKB_H
#define AKB_H

#include <iostream>
#include <string>
#include <stdarg.h>
#include <string.h>
#include <packet.h>
using namespace std;


/** An entry in the AKB cache.
 * 
 * The AKB on a node maintains a cache, so routes do not have to be
 * computed from scratch.  This structure describes a route cache
 * entry.  
 */
struct cache_entry{
  addr_t dst;       // final destination of the packet
  addr_t next_hop;  // pre-computed next hop
  int num_hops;     // number of hops to destination
  int valid;        // cache entries may become invalid
  int age;          // used to choose victim when cache is full
                    // and a new entry is needed
};


/** This sets a limit on the size of the AKB route cache.
 */
#define CACHESIZE 20

/** The route cache class.
 *
 * The route cache saves previously computed routes so that
 * findroute does not have to be called for every packet.
 * When the AKB changes, the cache is flushed.
 */
class routecache{
private:
  struct cache_entry entries[CACHESIZE];
public:
  routecache();

  /// add an entry, overwrite the oldest entry if necessary.
  void add(addr_t dst, addr_t next_hop, int numhops);

  /// return pointer to cache entry for node dst, NULL if not in cache
  struct cache_entry *find(addr_t dst);

  /// Mark all cache entries as invalid
  void routecache::flush();
};

/****************************************************************************
  Data types for the AKB  
****************************************************************************/

/** Different types of adjacencies (links).
 *
 * This is an enumerated type listing all of the possible types
 * of adjacencies.
 */
typedef enum{
  AKB_NONE,
  AKB_Static,
  ABK_Discovered,
  AKB_OnDemand,
  AKB_Scheduled,
  AKB_Predicted
}adjacency_t;

/** Definition of a record in the AKB.
 *
 * This structure defines an AKB entry. 
 * (some of the fields may not be used right now)
 */
typedef struct{
  addr_t src;
  addr_t dst;
  adjacency_t type;
  int active;
  double upat;
  double downat;
  double availability;
  int cost;
  double capacity;
  double delay;
  double errorrate;
  int qlength;
  addr_t assertedby;
  double ctime;
  double mtime;
  int used;
  int updated;
  double duty_cycle;
}AKB_rec;

/** Do two AKB records differ?
 *
 *  This function compares two AKB records.  It returns 1 if they
 * are different, and 0 if they are the same.
 */
int different(AKB_rec *a, AKB_rec *b);

/** Class to hold a list of adjacencies.
 *
 *  This class implements a linked list to hold information about
 *  adjacencies of network nodes.
 */
class adjacency_list{
 public:
  adjacency_list(){};

  /// Set pointer to next object in the adjacency list.
  void set_next(adjacency_list *n){next = n;};
  /// Get pointer to next object in the adjacency list.
  adjacency_list *get_next(){return next;};

  /// Get the AKB record referenced by this adjacency list object.
  AKB_rec *get_data() {return &data;}
  /// Set the AKB record referenced by this adjacency list object.
  void set_data(AKB_rec &d) {memcpy(&data,&d,sizeof(AKB_rec));}

 private:
  AKB_rec data;
  adjacency_list *next;
};


/** ABK records to be sent on an update packet.
 *
 * This is a class for holding the AKB records to be sent out on an AKB
 * update packet.  When the local AKB changes, an AKB payload is constructed
 * and put into an update packet.  The update packet is sent to the adjacent
 * nodes.
 */
class AKB_payload{
private:
  int size;
  AKB_rec *data;
  int *numrec;
  AKB_rec *records;
  AKB_rec *curr;
  int currnum;
public:
  AKB_payload();
  /// Make payload for count records for writing.  The data for the
  /// payload can then be set one AKB record at a time.
  AKB_payload(int count);


  /// Reconstruct payload for reading.  After receiving an AKB update
  /// packet, the pointed to the payload and the size are sent to
  /// this method, which re-constructs the AKB_payload object.
  AKB_payload(char *dat, int sz); 

  void construct(int count);
  void construct(char *dat, int sz);

  ~AKB_payload();

  /// Add a record to payload.
  void add_rec(AKB_rec *rec);

  /// Return the size of the payload.
  int payload_size();

  /// Return pointer to the payload AKB data.
  char *payload_data();

  /// Initialize for reading entries in payload data.
  /// This must be called before next_rec is called for the first time.
  void loop_init();

  /// Get next AKB record from the payload data.
  /// loop_init will initialize for the first record, then next_rec
  /// can be called repeadely.  NULL will be returned when there are
  /// no more records.
  AKB_rec *next_rec();

};


/** Each node has an Adjacency Knowledge Base (AKB).  
 *
 * This is the definition for the AKB.  The AKB is where information
 * about the network is stored on each node.  The AKB is kept up-to-date
 * through sharing of AKB update packets.  Each node tries to maintain 
 * its own AKB and update its neighbors.  The routing agent is responsible
 * for managing the AKB.
 */
class AKB{
 private:
  routecache cache;
  adjacency_list *l;
  addr_t route_node;  // findroute leaves the dest here if route found
  int findroute_recurse(int depth, addr_t src, addr_t dst, addr_t avoid);
 public:
  AKB() { l=NULL; }
  ~AKB();

  /// Returns record for adjacency from source to dest.
  /// Return NULL if no record exists.
  AKB_rec *get(addr_t source, addr_t dest);

  /// Insert a new record into the AKB (or replace an existing record).
  void update(AKB_rec &r);

  /// Remove a record from the AKB.
  void remove(adjacency_list *l);

  /// Dump all AKB records to cout.
  void dump();

  /// Return a pointer to the list of adjacencies.
  adjacency_list *get_list() { return l; }

  /// Find a route.
  ///
  /// Find a route from src to dst while
  /// avoiding the specified address.
  /// Returns the number of hops from src to dst, and stores
  /// the next hop in route_node.  Returns 0 if no route exists.
  int findroute(addr_t src, addr_t dst, addr_t avoid);

  /// Return the next hop found by findroute.
  ///
  /// The next hop is the node that we should send the packet to
  /// from the current node.
  addr_t &get_route(){return route_node;}

  /// Returns the payload for an AKB update packet.  
  ///
  /// If get_all is 0
  /// then the payload only contains AKB entries that have changed
  /// since the last update packet was sent.  If get_all is 1, then
  /// the payload contains all packets in the local AKB.
  AKB_payload *get_update_payload(int get_all);

  /// Return the average uptime for all links in the AKB.
  double upave();
};



#endif
