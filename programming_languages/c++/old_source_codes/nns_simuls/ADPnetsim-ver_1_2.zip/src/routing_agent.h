// -*- Mode: C++ -*-


#ifndef ROUTING_AGENT_H
#define ROUTING_AGENT_H

#include <assert.h>
#include <iostream>
#include <sim_object.h>
#include <event.h>
#include <packet.h>
#include <akb.h>
#include <packet_list.h>
#include <policy.h>

using namespace std;

/// Definition for the broadcast address.
#define BROADCAST 0xFFFFFFFF
/// Packets with this port number are meant for the routing agent.
#define ROUTING_PORT 0xFFFFFFFF

class node;
class event;

#define FLOOD_STRATEGY 0
#define GOSSIP_STRATEGY 1
#define SHORTEST_PATH_STRATEGY 2

#define NUM_STRATEGIES 3

/** Each node has a routing agent to make routing decisions.
 *
 * The routing agent, as implemented, uses an ADP method implemented
 * in the table_policy class to decide which routing strategy should
 * be used.  Rewards are based on ACK packets, and a database of previously
 * handled packets.  When an ACK comes in, the routing agent checks to see
 * if it handled the packet that is being ACKed.  If so, a positive reward
 * is generated for the state-action pair that the routing agent used to
 * handle the ACKed packet, and the ACK packet is propagated to other nodes.
 *  Otherwise the ACK is ignored.
 *
 * Information about other nodes and links is shared between routing
 * agents by the sharing of routing packets.  Each routing agent
 * maintains its own version of the Adjacency Knowledge Base (AKB). A
 * large part of the code in the routing agent is concerned with the
 * sharing of AKB information.
 */ 
class routing_agent:public sim_object{
 private:
  packet_DB packet_db; ///< Database of previously seen packets.
  node *Node;          ///< Node that this routing agent is running on.
  AKB akb;             ///< The local AKB.
  unsigned int seqnum; ///< Sequence number for packets we generate.
  table_policy  my_policy; ///< The ADP method and policy.
  int learning;        ///< Flag to tell whether we want to learn or not.

  /// Send acknowledgement that packet p was received at its destination.
  void send_ACK(Packet *p);
  /// Let our neighbors know what is in our AKB.
  void send_AKB_updates();
  /// Routing agents send themselves message events to time AKB updates, etc.
  void process_message(message_event *e);
  /// When link events occur, update AKB and send AKB updates to neighbors.
  void process_link_event(link_event *e);
  /// When a packet comes in, decide what to do with it.
  void process_packet(packet_event *e);

  /// If the packet contains AKB information, update local AKB.
  void process_routing_packet(Packet *p);

  /// On startup, prepare the available routing strategies.
  static void init_strategies();

  /// Clear old packets out of the packet_db, for memory and speed reasons.
  void perform_purge();

  /** \name Routing Strategies
   * \brief These are the routing strategies available to the routing agent.
   *
   * Routing strategies are kept in a separate file 
   * ( routing_strategies.cc ) for convenience.  It would make sense to
   * make a class for routing strategies as a subclass of routing
   * agent.  That would probably be a better approach in the long term,
   * but for now I am keeping it simple.
   *
   * All of the strategies take the packet as first argument.  The
   * second argument is a flag telling whether or not the packet is
   * a duplicate of another packet that was already sent out by this
   * node.  Some strategies may want to forward duplicates, while others
   * may avoid it.
   * 
   * Some of the strategies may be modified at compile time with the defines
   * at the top of routing_strategies.cc
   */
  //@(
  /// Array of boolean to tell which strategies we have enabled.
  static int *use_strategy;  

  /// A simple flooding strategy.
  void flood(Packet* p, int duplicate);

  /// A simple Gossip strategy.
  void gossip2(Packet *p, int duplicate, double prob, int range);

  /// Basic shortest path routing.
  void shortest_path(Packet *p, int duplicate);

  /*
    ===========================================================
  */
  //@}

 public: 
  /// DON'T USE THIS!
  routing_agent(){
    cerr<<"Routing agent constructed without node!\n";
    exit(1);
  }

  virtual ~routing_agent();

  /// Create a routing agent and attach it to a node.
  routing_agent(node *N);

  /// Print info to cout.
  virtual void dump();

  /// Event handler.
  virtual void handle(event *e);

  /// Initialize everything and prepare for simulation.
  virtual void start();

  /// Used to turn strategies on or off.
  static void set_strategy(int strategy,int val){
    assert((strategy < NUM_STRATEGIES)&&(strategy >= 0));
    if(use_strategy == NULL)
      routing_agent::init_strategies();
    use_strategy[strategy] = val;
  }
  
  /// Enable or disable learning in the routing agent.
  void learn(int l){learning = l;}

};


#endif
