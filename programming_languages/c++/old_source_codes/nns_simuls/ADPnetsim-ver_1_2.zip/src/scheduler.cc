// -*- Mode: C++ -*-

#include <scheduler.h>
#include <assert.h>

scheduler Scheduler;

scheduler::scheduler()
{
  sim_time=0.0;
}

scheduler::~scheduler()
{
  queue.flush();
}

  // add an event to the queue
void scheduler::schedule(event *e)
{
  queue.add(e);
}

// a convenience method for sending message events
void scheduler::schedule(double tm, sim_object *targ, char *cmd)
{
  message_event *ev = new message_event(tm,targ);
  ev->set_message(cmd);
  schedule(ev);
}

// pull first event off queue and pass it to its handler
int scheduler::dispatch()
{
  event *e=queue.get();
  if(e==NULL)
    return 0;
  
  if(sim_time > e->get_time())
    {
      cerr<<"Simulation time went backwards!\n";
      exit(1);
    }
  sim_time = e->get_time();
  
  if(sim_time > stop_time)
    {
      delete e;
      return 0;
    }

  e->get_handler()->handle(e);  
  return 1;
}

void scheduler::flush()
{
  queue.flush();
}

