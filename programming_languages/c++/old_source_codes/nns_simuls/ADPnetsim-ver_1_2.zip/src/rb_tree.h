// ANSI C Headers 
#include <stdlib.h> 

// C++ STL Headers 
#include <functional> 
#include <iostream> 
#include <queue> 
#include <string> 
#include <vector>

#include <event.h>


using namespace std;

class CompareEvents{
 public:
  int operator() (const event* &x,  const event* &y)
  {
    return *x<*y;
  }


priority_queue<event*, vector<event*>, CompareEvents> e_queue;

class event_priority_queue_stl{
private:
  e_queue q;


public:
  event_priority_queue();
  ~event_priority_queue();

  void add(event *e){
    q.push(e);
  }
  
  event *get(){
    event *e = q.top();
    q.pop();
    return e;
   }
  
  int remove(event *e){
    cerr<<"remove method not implemented\n";
    exit(1);
  }

  void set_length(int len);

  void flush(){
    while ( !q.empty() ) q.pop(); 
  }
};
  
