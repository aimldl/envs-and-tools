

#include <node.h>
#include <link.h>
#include <scheduler.h>
#include <trace.h>

/// Static integer to assign unique addresses to nodes.
addr_t node::last_address=0;

static char tmpstr[1024];

node::node()
{
  address=last_address++;
  links=NULL;
  ragent=new routing_agent(this);
  ports = new portmapper();
  num_links=0;

  sprintf(tmpstr,"Node %d has address %d\n",address,address);
  trace.trace(tmpstr);
  sprintf(tmpstr,"n -t * -a %d -s %d -S UP\n",address,address);
  trace.namtrace(tmpstr);
}

node::~node()
{
  //cout << "node destructor called\n";
  link_list *l;
  while(links != NULL)
    {
      l = links->next;
      delete links;
      links = l;
    }
  // this is done by the global object destructor
}


   
// assign agent a port and return the port number
int node::install_agent(data_agent *a)
{
  return ports->add(a);
}

void node::add_link(simplex_link *l)
{
  link_list *new_link = new link_list;
  new_link->link=l;
  new_link->neighbor = l->get_dst();
  new_link->next = links;
  links = new_link;
  num_links++;
}

void node::handle(event *e){

// #ifdef DEBUG
//   cout<<"node event handler called\n";
// #endif

  switch(e->type())
    {
    case event::packet:   // find status of packet, and move it along
      // deliver the event to the routing agent
      e->set_handler(ragent);
      Scheduler.schedule(e);
      break;
    case event::link:   // change status of link
      // deliver the event to the routing agent
      e->set_handler(ragent);
      Scheduler.schedule(e);
      break;
      //case event::message:  // process a message 
      // change our status. 
      // drop all packets currently on wire or in transmission.
      // notify the nodes that this link is connected to
      // schedule the next link_up event
      //break;
    default:
      cerr<<"Node event handler called with bad event type\n";
      exit(1);
    }

}


void node::dump()
{
  sim_object::dump();
  printf("Node\n");
}

