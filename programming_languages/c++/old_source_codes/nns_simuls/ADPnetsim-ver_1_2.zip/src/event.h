// -*- Mode: C++ -*-

#ifndef EVENT_H
#define EVENT_H

#include <sim_object.h>
#include <packet.h>

/// The base class for events.
///
/// Since ADPnetsim is a discrete event simulator, events are
/// the core data type. The event class encapsulates everything
/// that all events have in common, and allows the scheduler and 
/// event queue to manage events without regard to their type.
class event{
public: 
  /// A list of the possible event types.
  typedef enum 
    {
      unknown,     ///< If the event type is unknown, then something is wrong.
      packet,      ///< The event describes a packet.
      link,        ///< The event means that a link has changed state.
      message      ///< The event represents a message.
    } event_type;

  /// Create an event.
  ///
  /// Create an event. 
  /// \arg e_time Time in seconds from beginning of simulation that the event will occur.
  /// \arg e_handler Pointer to the sim_object that will handle the event.
  event(double e_time,sim_object *e_handler);
  event();
  virtual ~event();

  /// Get the event type.
  event_type type();

  /// Set pointer to next event in a linked list.
  ///
  /// In addition to being managed by the event queue, events can
  /// be stored on a linked list.  A network link may need to keep linked
  /// lists to track the packet events that are in the send buffer and
  /// packet events on the wire.  If the link goes down, the linked lists
  /// can be traversed, marking each packet event as canceled.  Then, when
  /// the marked event reaches the head of the event queue, it is
  /// quietly discarded.
  void set_next(event *n);

  /// Get pointer to next event in a linked list.
  ///
  /// See event::set_next() for an explaination.
  event *get_next();

  /// Set the time that the event will occur.
  ///
  /// \arg e_time Time in seconds from beginning of simulation that
  /// the event will occur.
  ///
  /// When a sim_object handles an event, it may need to pass the
  /// event to another sim_object, or to itself.  The easiest way
  /// to accomplish this is to set the time that the event will occur using
  /// set_time(), set the handler using set_handler(), 
  /// and put it back on the event queue.
  void set_time(double e_time);

  /// Get the time that the event will occur (or did occurred).
  double get_time();

  /// Set the sim_object that will handle the event.
  ///
  /// When a sim_object handles an event, it may need to pass the
  /// event to another sim_object, or to itself.  The easiest way
  /// to accomplish this is to set the time that the event will occur using
  /// set_time(), set the handler using set_handler(), 
  /// and put it back on the event queue.
  void set_handler(sim_object *h);

  /// Find out who is or will be handling the event.
  sim_object *get_handler();

  /// Print information on cout.
  virtual void dump(){cout << "Trying to dump unknown event type\n";}

  /// Get the unique ID for an event.
  int get_ID(){return unique_id;}
  
  /// Operator to compare two events
  ///
  /// Events are compared by the time that they occur.  
  /// If the event
  /// on the left of "<" occurs before the event on the right, then
  /// 1 is returned.  If the event
  /// on the left of "<" occurs after the event on the right, then
  /// 0 is returned.  If the two events occur at the same time, then
  /// they are compared based on their unique ID.  
  /// If the ID of the event
  /// on the left of "<" is less than the ID of the event on the right, then
  /// 1 is returned.  Otherwise, 0 is returned.
  ///
  int operator < (const event &r)const
  {
    if(time < r.time)  // if time of this is less
      return 1;        // then this is less
    if(time > r.time)  // if time of r is less
      return 0;        // then this is not less
    if(unique_id < r.unique_id) // if times are equal, and unique ID is less
      return 1;        // then this is less
    return 0;          // else this is not less
  }

  /// Operator to compare two events
  ///
  /// Events are compared by the time that they occur.  
  /// If the event
  /// on the left of ">" occurs after the event on the right, then
  /// 1 is returned.  If the event
  /// on the left of ">" occurs before the event on the right, then
  /// 0 is returned.  If the two events occur at the same time, then
  /// they are compared based on their unique ID.  
  /// If the ID of the event
  /// on the left of ">" is greater than the ID of the event on the right, then
  /// 1 is returned.  Otherwise, 0 is returned.
  ///
  int operator > (const event &r)const
  {
    if(time > r.time)
      return 1;
    if(time < r.time)
      return 0;
    if(unique_id > r.unique_id)
      return 1;
    return 0;
  }
  
protected:
  event_type _type;    ///< Derived classes need access to this.
private:
  double time;         ///< Time in seconds that the event will occur.
  sim_object *handler; ///< Object that will handle the event.
  unsigned long unique_id; ///< All events get a unique ID.
  static int next_id;  ///< Static int for assigning unique IDs.
};

/// Event concerning a packet.
///
/// Packets can be sent from one sim object to another, and the link
/// sim_object manages simulating the packet as it enters a send queue,
/// gets transmitted, and travels down the wire.
class packet_event:public event{
public:
  /// Packets can be in several states.
  typedef enum 
    { unknown,  ///< State of the packet is not known.
      xmit,     ///< The packet is currently being transmitted.
      on_wire,  ///< The packet is currently travelling down a wire.
      waiting   ///< The packet is in a send queue.
    } packet_status;
  
private:
  Packet *_pack;
  packet_status stat;
  
public:
  packet_event():event(){}
  packet_event(double e_time,sim_object *e_handler):event(e_time,e_handler){
    _type=packet;
    _pack=NULL;
    stat=unknown;
  }
  
  virtual ~packet_event(){if(_pack != NULL) delete _pack;}

  /// Set a pointer to the packet that this event concerns.
  void set_packet(Packet *p){
    _pack = p;
  }

  /// Get a pointer to the packet that this event concerns.
  Packet *get_packet(){
    return _pack;
  }
  
  /// Get the state of the packet.
  packet_status get_status(){return stat;}
  /// Set the state of the packet.
  void set_status(packet_status s){stat = s;}

  virtual void dump();
};

/// Link events describe things that can happen to links.
class link_event:public event{
public:
  /// Links can be up or down.
  typedef enum 
    { unknown,  ///< State of the link is unknown.
      down,     ///< The link is down.
      up        ///< The link is up.
    } link_status;
  
  link_event():event(){}

  link_event(double e_time,sim_object *e_handler):event(e_time,e_handler){
    _type=link;
  }

  virtual ~link_event(){}

  /// Set the state of the link to down.
  ///
  /// This can only be used during the initialization phase, and
  /// not after the simulation has started.
  void set_down(){stat=down;}
  /// Set the state of the link to up.
  ///
  /// This can only be used during the initialization phase, and
  /// not after the simulation has started.
  void set_up(){stat=up;} 

  /// Get the state of the link.
  link_status get_status(){return stat;}

  /// Set pointer to the link that this event concerns.
  void set_link(void *l){lnk = l;}
  /// Get pointer to the link that this event concerns.
  void *get_link(){return lnk;}

  virtual void dump(){cout<<"Dump for link event\n";}
  
private:
  link_status stat;  ///< State of the link.
  void *lnk;         ///< Pointer to the link sim_object.
};

/// Message events allow sim_objects to communicate flexibly.
///
/// Aside from packet events and link events, objects may need to
/// implement timers, signal each other, etc.  The message_event
/// provides a mechanism to accomplish this.
class message_event:public event{
private:
  char *command;   ///< The message.
  
public:
  message_event():event(){}

  message_event(double e_time,sim_object *e_handler):event(e_time,e_handler){
    _type = message;
    command = NULL;
  };
  
  virtual ~message_event(){
    if(command != NULL) delete[] command;}

  /// Set the message contents.
  void set_message(char *c){
    if(c != NULL)
      {
	command = new char[strlen(c)+1];
	strcpy(command,c);
      }
  }

  /// Get the message contents.
  const char *const get_message(){
    return command;
  }

  virtual void dump(){cout<<"Dump for message event '"<<command<<"'\n";};
    
};

/// A doubly linked list of events.  
///
/// This object class is used by the link objects
/// to hold packet events for their send queues, and to hold pointers
/// to packets that are on the wire.  When a link goes down, all the
/// packet events on the wire need to be removed from the scheduler.
/// However the STL priority queue implementation does not allow
/// for events to be removed from anywhere except the head, so instead
/// of removing them, they are marked so that the scheduler will throw
/// them away when they reach the head of the queue.
///
/// I thought about using STL deque to implement this, but couldn't 
/// figure out how to efficiently implement the remove() method using
/// the STL deque.   
class event_queue{
protected:
  int queue_limit;
  int in_queue;

  typedef struct evlist{
    event *ev;
    // next and prev are for maintaining the doubly linked list structure
    struct evlist *next;
    struct evlist *prev;
  }event_list;

  event_list *head, *tail, *root;


public:
  event_queue();
  ~event_queue();

  // add an event.  If the queue is full, return pointer to victim
  event* add(event *e);

  // unlink the head of the queue and return pointer to it
  event *get();

  // return pointer to head of queue without unlinking it
  event *peek();
  
  int remove(event *e);

  void set_length(int len);
  int get_length(){return queue_limit;}

  void flush();

  int count(){return in_queue;}
    
};


// Simple linked list priority queue.  Profiling showed that it
// was a serious bottleneck.  I started an implementation using
// a red-black tree, but then checked the STL library and went
// with that
// class event_priority_queue_ll:public event_queue{
// public:
//   void add(event *e);
// };


// C++ STL Headers 
#include <functional> 
#include <iostream> 
#include <queue> 
#include <string> 
#include <vector>
#include <deque>
#include <list>

/// The STL priority queue class stores pointers to events, so we need a
/// class that it can use to compare events using their pointers.
class CompareEvents{  
public:
  int operator() (event* &x,  event* &y)
  {
    // we use the ">" because we want the event with the lowest
    // time/ID (highest priority) at the beginning.
    return *x>*y;
  }
};


/** Priority queue for events.
 *
 * The event queue is a priority queue implemented using the
 * C++ STL priority queue template. event_priority_queue_stl is basically
 * just a wrapper around the STL implementation. 
 * It uses a heap as the data structure, and is pretty fast.  A red-black
 * tree implementation may be a little faster, but probably not worth
 * implementing at this point.
 *
 * NOTE: there is no enforcement of the queue length setting
 * in the STL priority queue.
 */
class event_priority_queue_stl{
private:
  /**  Instantiation of the class template.
   *
   *   The queue stores pointers to events.
   *   The container for the event pointers is a vector.
   *   The class CompareEvents has the ordering operator for the pointers.
   */
  priority_queue<event*, vector<event*>, CompareEvents> q;
public:

  /// Add an event to the queue.
  void add(event *e){
    q.push(e);
  }
  
  /// Get the event from the front of the queue.
  event *get(){
    event *e = q.top();
    if(e != NULL)
      q.pop();
    return e;
   }

  /** This method should allow an event to be removed from anywhere in the
    * queue.
    *
    * There is no way to remove an event from the middle of the heap,
    * so this method is not implemented in the STL version.  Using it
    * will cause the program to exit with an error message.
    */
  int remove(event *e){
    cerr<<"remove method not implemented\n";
    exit(1);
  }

  /** This method should set a limit the number of items
   * that can be in the queue.
   *
   * This method does not work for the STL queue.  Its size is unbounded.
   */
  void set_length(int len);

  /// Delete all events in the queue.
  void flush(){
    event *e;
    while ( !q.empty() ) 
      {
	e = q.top();
	delete e;
	q.pop(); 
      }
  }

  /// Return the number of items in the queue.
  int size(){
    return q.size();
  }
};
  


#endif
