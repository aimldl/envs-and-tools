// -*- Mode: C++ -*-

#ifndef POLICY_H
#define POLICY_H

#define NUM_DC 20
#define NUM_PROT 2

#include <iostream>
using namespace std;

/** This is where learning takes place.
 *
 * The policy is actually more than just a policy.  It is an
 * implemetation of an ADP method.  The policy class is the
 * base class for these learning methods.  Classes derived from
 * this can be written as needed.  I really need to do some cleaning
 * in this class and make it more of an abstract class.  I'm not
 * really even using the policy class at this point. 
 */
class policy{
 private:
  /// This really should not be here.
  typedef struct {
    double state;
    double value;
  }qval;

  /// This really should not even be here.
  qval Q[NUM_PROT][NUM_DC];

 public:
  policy();
  /// This really should not be here.
  int choose(double dc);
};

/** An ADP method based on a table-lookup implementation.
 *
 * Table lookup is simple to program, and often gives adequate
 * results.  Therefore, it was the first method I implemented.
 * The table_policy class does simple associative learning (TD with
 * a discount factor of 1).
 */
class table_policy{
private:
  int nactions;   ///< Number of actions available.
  int nstates;    ///< Number of states in the table
  double alpha;   ///< Learning rate.
  double epsilon; ///< Probability of choosing a random action.
  double **Q;     ///< \f$ Q_s^a \f$ values, stored as Q[state][action].

  /// Set up the Q table.
  void allocate_table();
  /// Delete the Q table.
  void delete_table();

 public:
  table_policy(){
    cerr<<"Table policy constructed without params!\n";
    exit(1);
  }
  table_policy(int numstates, int numactions);  
  ~table_policy();
  /// Select an action, given a state.
  int choose(int state);
  /// Do some learning, given previous state, previous action, and reward.
  void learn(int state, int action, double reward);
  /// Save what has been learned.
  void save(char *filename);
  /// Restore what was previously learned.
  void restore(char *filename);

  /// Dump information to cout.
  void print();

  /// Set the learning rate.
  void set_alpha(double a){alpha = a;}
  /// Set the probability of choosing a random action.
  void set_epsilon(double e){epsilon = e;}
};

#endif
