// -*- Mode: C++ -*-

#include <assert.h>
#include <packet_list.h>
#include <scheduler.h>
#include <iostream>
#include <Jenkins_hash.h>

using namespace std;



void packet_list::set_next(packet_list *n)
{
  next = n;
}

packet_list *packet_list::get_next()
{
  return next;
}

packet_rec *packet_list::get_data()
{
  return data;
}

void packet_list::set_data(packet_rec *d)
{ 
  data = d; 
}


packet_DB_ll::packet_DB_ll()
{
  l=NULL; 
  rec_count=0;
}


packet_DB_ll::~packet_DB_ll()
{
  packet_list *d=l;
  while(l!=NULL)
    {
      l = l->get_next();
      delete d;
      d=l;
    }
}

static int equal(packet_header &l, packet_header &r)
{
  // check source and dest addresses, and seqnum
  return ((l.dst_addr == r.dst_addr)&&
	  (l.dst_port == r.dst_port)&&
	  (l.src_addr == r.src_addr)&&
	  (l.src_port == r.src_port)&&
	  (l.seqnum == r.seqnum));
}

// Database for recording packets.
// This needs to be REALLY efficient.  Initial implementation of
// packet_DB was a linked list.  The program spent over 66% of its
// time in the get() method.  Profiling revealed that packet_DB::add()
// was called 728485 times on the (tiny) test program, while packet_DB:get() 
// was called 1602714 times.  Both adding and retrieving need to be
// as efficient as possible, with emphasis on retrieving. purge() was 
// only called 113 times, so deletion can be not so efficient.


// The original packet_DB was renamed to packet_DB_ll, and used
// to handle collisions in the hash table implementation.  Each
// entry in the hash table is a packet_DB_ll.

packet_rec *packet_DB_ll::get(packet_header *h)
{
  packet_list *d=l;
  packet_rec *r;
  int done=0;
  while((!done)&&(d!=NULL))
    {
      r = d->get_data();
      if(equal(r->h,*h))
	done = 1;
      else
	d = d->get_next();
    }
  if(d == NULL)
    return NULL;
  else
    return r;
}

void packet_DB_ll::add(packet_rec *r)
{
  
  r->ctime = Scheduler.time();
  packet_list *x=new packet_list;
  x->set_data(r);
  x->set_next(l);
  l=x;
  rec_count++;
//   if(rec_count > 1) 
//     cout<<"Collision "<<rec_count<<"\n";
}

packet_list::head_tail *packet_DB_ll::purge(double ltime)
{
  packet_list::head_tail *ptrs = new packet_list::head_tail;
  packet_list *tmp, *tmp2;
  
  ptrs->head = NULL;
  ptrs->tail = NULL;
  ptrs->num_recs = 0;

  // move entire list to tmp
  tmp = l;
  // start over with l = null
  l = NULL;
  rec_count = 0;
  while(tmp != NULL)
    {
      // pull a packet record off of tmp
      tmp2 = tmp;
      tmp = tmp->get_next();
      // if the packet we just got is an old packet
      if(tmp2->get_data()->ctime < ltime)
	{
	  // add it to old_packets
	  if(ptrs->tail == NULL)
	    ptrs->tail = tmp2;
	  tmp2->set_next(ptrs->head);
	  ptrs->head = tmp2;
	  ptrs->num_recs++;
	}
      else
	{
	  // otherwise, put it back on l
	  rec_count++;
	  tmp2->set_next(l);
	  l = tmp2;
	}
    }
  return ptrs;
}



// this is a very time-consuming thing to do, and will only pay off
// on very large data sets that will be searched a lot.
#define GROW_HASH_TABLE

#define MIN_NUM_BITS   12
#define MAX_NUM_BITS   18

#define MIN_TABLE_SIZE (1<<MIN_NUM_BITS)
#define MAX_TABLE_SIZE (1<<MAX_NUM_BITS)



packet_DB::packet_DB()
{
  num_bits = MIN_NUM_BITS;
  table_size = MIN_TABLE_SIZE;
  table = new packet_DB_ll[table_size];
  add_count = 0;
}

packet_DB::~packet_DB()  
{
#ifdef DEBUG
  hash_stats();
#endif
  delete[] table;
}

// get record for adjacency from source to dest
packet_rec *packet_DB::get(packet_header *h)
{
  int hash_key;
  hash_key = get_hash_key(h);
  return table[hash_key].get(h);
}

// this is a very time-consuming thing to do, and will only pay off
// on very large data sets that will be searched a lot.
void packet_DB::grow_table()
{
  int i;
  // move the old table and its size to temp variables
  int old_table_size = table_size;
  packet_DB_ll *old_table = table;
  add_count = 0;

  // create the new table
  table_size *= 4;
  num_bits+=2;
  packet_DB_ll *tmp = new packet_DB_ll[table_size];
  table = tmp;

  //cout<<"Hash table growing to "<<table_size<<endl;

  packet_list *l;
  packet_rec *p;
  int hash_key;

  // re-hash the data into the new table
  for(i=0;i<old_table_size;i++)
    {
      l = old_table[i].get_list();
      while(l != NULL)
	{
	  p = l->get_data();
	  l->set_data(NULL);
	  
	  hash_key = get_hash_key(&p->h);
	  table[hash_key].add(p);
	  ++add_count;

	  l = l->get_next();
	}
    }
  if(old_table != NULL)
    delete[] old_table;
}

// insert a new record into the database (or replace an existing record)
void packet_DB::add(packet_rec *r)
{
  int hash_key;
  hash_key = get_hash_key(&r->h);
  table[hash_key].add(r);  

  #ifdef GROW_HASH_TABLE
  // if the average # of records in each table entry is greater than 4
  if((++add_count >= table_size*4)&&(table_size<MAX_TABLE_SIZE))
    grow_table();
  #endif
}

// remove a record from the database
// void packet_DB::remove(packet_list *r);  // Not implemented

void packet_DB::hash_stats()
{
  // show hash table stats
  int i;
  int zerocount=0;
  int max = 0;
  int total = 0;
  int c;
  for(i=0;i<table_size;i++)
    {
      c = table[i].num_records();
      if(c == 0)
	zerocount++;
      else
	{
	  if(c>max)
	    max = c;
	  total += c;
	}
    }
  cout<<"Hash table has "<<total<<" records.  Max="<<max<<" ave="<<
    (double)total/table_size<<" zerocount="<<zerocount<<endl;
}

// remove all packet records older than ltime from the DB and return
// a pointer to them
packet_list::head_tail *packet_DB::purge(double ltime)
{
  int i;
  packet_list::head_tail *ptrs;
  packet_list::head_tail *ht=new packet_list::head_tail;
  ht->head=NULL;
  ht->tail=NULL;
  ht->num_recs = 0;
  for(i=0;i<table_size;i++)
    {
      ptrs = table[i].purge(ltime);
      add_count -= ptrs->num_recs;
      ht->num_recs += ptrs->num_recs;
      if(ht->head == NULL)
	{
	  ht->head=ptrs->head;
	  ht->tail=ptrs->tail;
	}
      else
	{
	  if(ptrs->head != NULL)
	    {
	      ht->tail->set_next(ptrs->head);
	      ht->tail = ptrs->tail;
	    }	    
	}	  
      delete ptrs;
    }
  return ht;
}

int packet_DB::get_hash_key(packet_header *h)
{
  int hashval =  Jenkins_hash((ub1 *)h,5 * sizeof(int),0xa39f4b68);
  return hashval & hashmask(num_bits);
}



