
// -*- Mode: C++ -*-

#include <event.h>

//#define BALANCED_TREE_CHECK
//#define BALANCED_TREE
//#define KEEP_NODE_COUNTS
//#define DEBUG_EVENT_QUEUE

int event::next_id = 0;



event::event(double e_time,sim_object *e_handler)
{
  time = e_time;
  handler = e_handler;
  _type = unknown;
  unique_id = next_id++;
}

event::event()
{
  cout<<"Event created without time or handler\n"; exit(1);
}

event::~event()
{
  //cout<<"Event destructor called\n";
}

event::event_type event::type()
{
  return _type;
}

void event::set_time(double e_time)
{
  time = e_time;
}

double event::get_time()
{
  return time;
}

void event::set_handler(sim_object *h)
{
  handler=h;
}

sim_object *event::get_handler()
{
  return handler;
}

void packet_event::dump()
{
  cout<<"Dump of packet event\n";
  cout<<"Status = "<<stat<<endl;
  _pack->dump();
}


event_queue::event_queue()
{
  head = tail = NULL;
  in_queue = 0;
  queue_limit = -1;  // -1 means no limit
}
  
event_queue::~event_queue()
{
  //cout<<"event_queue destructor called\n";
  event_list *x = head;
  while(x != NULL)
    {
      head=head->next;
      delete x;
      x = head;
    }
}

void event_queue::flush()
{
  event *e = get();
  while(e != NULL)
    {
      delete e;
      e = get();
    }
  in_queue = 0;
}

event *event_queue::add(event *e)
{
  event *victim = NULL;    
  if(queue_limit != -1)
    {
      if(queue_limit == 0)
	{
	  // zero length queue drop the packet
	  delete e;
	  return victim;
	}
      if (in_queue >= queue_limit)
	{
	  // queue is full. drop the oldest packet in the queue
	  victim = get();      
	}
    }
  in_queue++;
  event_list *x = new event_list;
  x->ev = e;
  x->next = NULL;
  x->prev = tail;

  if(tail == NULL)
    head = tail = x;
  else
    {
      tail->next = x;
      tail = x;
    }
  return victim;
}


event *event_queue::get()
{
  event *e = NULL;
  if(head != NULL)
    {
      in_queue--;
      e = head->ev;
      event_list *x = head;
      head = head->next;
      delete x;
      if(head != NULL)
	head->prev = NULL;
      else
	tail = NULL;
    }
  return e;
}

event *event_queue::peek()
{
  if(head != NULL)
    return head->ev;
  return NULL;
}
 
int event_queue::remove(event *e)
{
  event_list *c = head;
  
  while((c != NULL)&&(c->ev != e))
    c = c->next;
  if(c==NULL)
    return 0;

  in_queue--;
  if(head == tail)
    {
      delete c;
      head = tail = NULL;
    }
  else
    {
      event_list *prev = c->prev;
      event_list *next = c->next;
      if(prev == NULL)
	{
	  head = next;
	  next->prev = NULL;
	}
      else
	if(next == NULL)
	  {
	    tail = prev;
	    prev->next = NULL;
	  }
	else
	  {
	    prev->next = next;
	    next->prev = prev;
	  }
      delete c;
    }
  return 1;  
}
    

    
void event_queue::set_length(int len)
{
  queue_limit = len;
}

// old linked list implementation of the priority queue
// the new STL version is all in event.h
// void event_priority_queue_ll::add(event *e)
// {
//   if(queue_limit && (in_queue >= queue_limit))
//     { // queue is full.  drop the oldest packet
//       event *victim = get();      
//       delete victim;
//     }
//   else
//     in_queue++;

//   event_list *x = new event_list;
//   x->ev = e;

//   if(tail == NULL)
//     {
//       head = tail = x;
//       x->next = x->prev = NULL;
//     }
//   else
//     {
// #define SEARCH_BEGINNING
// #ifdef SEARCH_BEGINNING
//       event_list *put_before = head;
//       while((put_before != NULL)&&(*x->ev > *put_before->ev))
// 	put_before = put_before->next;

//       if(put_before == NULL) // it goes at the tail
// 	{
// 	  x->prev = tail;
// 	  tail = x;
// 	  x->next = NULL;
// 	  x->prev->next = x;
// 	}
//       else
// 	if(put_before == head) // it goes at the head
// 	  {
// 	    x->next = head;
// 	    head = x;
// 	    x->prev = NULL;
// 	    x->next->prev = x;
// 	  }  
// 	else
// 	  {
// 	    x->next = put_before;
// 	    x->prev = put_before->prev;
// 	    put_before->prev = x;
// 	    x->prev->next = x;
// 	  }
// #else
//       event_list *put_after = tail;
//       while((put_after != NULL)&&(*x->ev < *put_after->ev))
// 	put_after = put_after->prev;
//       if(put_after == NULL) // it goes at the head
// 	{
// 	  x->next = head;
// 	  head = x;
// 	  x->prev = NULL;
// 	  x->next->prev = x;
// 	}
//       else
// 	if(put_after == tail) // it goes at the tail
// 	  {
// 	    x->prev = tail;
// 	    tail = x;	    
// 	    x->next = NULL;
// 	    x->prev->next = x;
// 	  }  
// 	else
// 	  {
// 	    x->prev = put_after;
// 	    x->next = put_after->next;
// 	    put_after->next = x;
// 	    x->next->prev = x;
// 	  }
// #endif
//     }
// }

