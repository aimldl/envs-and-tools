// -*- Mode: C++ -*-

#include <sim_object.h>
#include <routing_agent.h>
#include <packet.h>
#include <event.h>
#include <scheduler.h>
#include <link.h>
#include <node.h>
#include <packet_list.h>

#define STARTUP_WINDOW  15.0
#define UPDATE_INTERVAL 15.0

#define PURGE_INTERVAL  10.0

#define JITTER (drand48()-0.5)


static char* timer_msg="timer";
static char* purge_msg="purge";

// an array of bools for whether or not to use each available strategy
int *routing_agent::use_strategy = NULL;

void routing_agent::init_strategies()
{
  int i;
  use_strategy = new int[NUM_STRATEGIES];
  for(i=0;i<NUM_STRATEGIES;i++)
    use_strategy[i] = 0;
}


routing_agent::routing_agent(node *N):my_policy(32,2)
{
  // try to spread out AKB update times randomly over STARTUP_WINDOW
  Scheduler.schedule(STARTUP_WINDOW-STARTUP_WINDOW*(0.5+JITTER),
		     this,
		     timer_msg);
  Scheduler.schedule(Scheduler.time()+3*PURGE_INTERVAL+JITTER,
		     this,
		     purge_msg);
  Node = N;
  seqnum = 0;

  // check for policy file and load if it exists.
  char tmp[256];
  sprintf(tmp,"policies/Policy.%02d",Node->get_address());
  my_policy.restore(tmp);
  my_policy.set_alpha(0.001);
  my_policy.set_epsilon(0.001);
}

routing_agent::~routing_agent()
{
  // save the policy
  char tmp[256];

  perform_purge();

  sprintf(tmp,"policies/Policy.%02d",Node->get_address());
  my_policy.save(tmp);

  //dump();
}


void routing_agent::dump(){
  sim_object::dump();
  printf("Routing Agent\n");
  cout <<endl<< "AKB for node "<<Node->get_address()<<endl;
  akb.dump();
  cout<<endl;

}

void routing_agent::send_AKB_updates()
{
// #ifdef DEBUG
//   cout<<"ragent for node "<<Node->get_ID()<<" sending updates at time "<<
//     Scheduler.time()<<"\n";
// #endif

  // set the payload to all AKB records that have changed since last update,
  // or to complete list, with small probability
  AKB_payload *payload;
  if(drand48()<0.95)
    payload= akb.get_update_payload(0);
  else
    payload= akb.get_update_payload(1);


  if((payload != NULL) && (payload->payload_size() > sizeof(int)))
    {
      // create a packet to inform neighbors.
      Packet *lp = new Packet();

      packet_header *h = new packet_header;
      h->dst_addr = BROADCAST;
      h->dst_port = ROUTING_PORT;
      h->src_addr = Node->get_address();
      h->src_port = ROUTING_PORT;
      h->last_hop = Node->get_address();
      h->seqnum = seqnum++;
      h->type = routing_data;
      h->ttl = 100;
      h->hopcount = 0;
      lp->set_header(h);

      lp->set_payload(payload->payload_data(),payload->payload_size());

      // send it down all links that are up

      flood(lp,0);

      // or gossip2 it
      // gossip2(lp,0,1,1);

      delete h;
      delete lp;
    }
  delete payload;
}

void routing_agent::send_ACK(Packet *p)
{
// #ifdef DEBUG
//   cout<<"ragent for node "<<Node->get_ID()<<" sending ACK at time "<<
//     Scheduler.time()<<"\n";
// #endif

  // create a packet to inform neighbors.
  Packet *lp = new Packet();
  
  packet_header *h = new packet_header;
  h->dst_addr = BROADCAST;
  h->dst_port = ROUTING_PORT;
  h->src_addr = Node->get_address();
  h->src_port = ROUTING_PORT;
  h->last_hop = Node->get_address();
  h->seqnum = seqnum++;
  h->type = routing_ack;
  h->ttl = 100;
  h->hopcount = 0;
  lp->set_header(h);

  packet_header *ph = p->get_header();
  
  lp->set_payload(ph,sizeof(packet_header));
  
  // send it down all links that are up
  
  flood(lp,0);
  
  // or gossip2 it
  // gossip2(lp,0,1,1);
  
}


void routing_agent::process_routing_packet(Packet *p)
{
  packet_header *h = p->get_header();
  AKB_payload *AKB_recs;
  AKB_rec *rec;
  packet_rec *r;
  char *tmp;
  int i;

  switch(h->type)
    {
    case routing_ack:
      // check to see if we processed the original packet
      r = packet_db.get((packet_header*)p->get_payload());
      // if we did, then generate a reward
      if(r != NULL)
	{
// #ifdef DEBUG
//	  cout<<"ragent for node "<<Node->get_ID()<<" got ACK at time "<<
//	    Scheduler.time()<<" LEARNING\n";
// #endif
	  // do some learning
	  // cout<<r->state<<" "<<r->action<<endl;
	  if(r->action != -1) // don't learn on locally delivered packets
	    {
	      if(learning && (r->h.type==data))
		if(r->ACK_received == 0)
		  my_policy.learn(r->state,r->action,1.0);
		else
		  my_policy.learn(r->state,r->action,0.0);
	      r->ACK_received = 1;
	    }
	}
      // forward it.
      gossip2(p,0,0.95,0);
      break;
    case routing_data:
      AKB_recs = new AKB_payload((char *)p->get_payload(),
				 p->get_payload_size());
      AKB_recs->loop_init();
      while((rec = AKB_recs->next_rec())!=NULL)
	akb.update(*rec);
      delete AKB_recs;
      // send_AKB_updates();  // send updates if anything changed
      gossip2(p,0,0.95,0);

      break;
    default:
      cerr<<"routing agent recieved a weird packet type\n";
      exit(1);
      break;
    }
}


/** Calculate the current state as an integer.
 *  
 *  Since we are using a lookup table, we have to convert
 * the average link availability, and a Boolean telling whether or
 * not there is a path to the destination, into an index for the
 * lookup table.  This
 * helper function discretizes upave, shifts it left, and adds haveroute.
 */
int get_state(double upave, int routelength)
{
  assert ((upave >= 0.0)&&(upave <= 1.0));
  int tmp = (int) (upave*16.0);         // creates a 4 bit number
  if(tmp>15)
    tmp = 15;
  // cout<<tmp<<endl;
  if(routelength > 0)
    routelength = 1;
  tmp = (tmp << 1) + routelength; // makes it a 5 bit number
  return tmp;
}

void routing_agent::process_packet(packet_event *e)
{
  Packet *p = e->get_packet();
  packet_header *h = p->get_header();
  int duplicate = 0;
  // check to see if we have received this packet before
  packet_rec *r = packet_db.get(h);
  if(r != NULL)
    {
      r->ctime = Scheduler.time();
      duplicate = 1;
    }

  if((h->dst_addr == Node->get_address())||(h->dst_addr == BROADCAST))
    {
      // packet is either broadcast or is at its destination
      if(duplicate)
	{
	  delete e;
	}
      else
	{
	  if(h->dst_port == ROUTING_PORT)
	    {
#ifdef DEBUG
	      cout<<Scheduler.time()<<" routing agent on node "<<
		Node->get_address()<< " got a packet\n";
#endif
	      // add it to our packet db so we can drop duplicates
	      packet_rec *r = new packet_rec;
	      r->ACK_received = 0;
	      r->h = *h;    // save the header in the packet record
	      // save the state variable
	      // get the average time that links are up
	      double s = akb.upave();
	      int have_route =  1;
	      r->state = get_state(s,have_route);
	      // save the action chosen
	      r->action = -1;
	      packet_db.add(r);
	      process_routing_packet(p);
	      delete e;
	    }
	  else
	    {
	      // add it to our packet db
	      packet_rec *r = new packet_rec;
	      r->ACK_received = 0;
	      r->h = *h;    // save the header in the packet record
	      // save the state variables
	      double s = akb.upave();
	      int have_route =  1;
	      r->state = get_state(s,have_route);
	      // save the action chosen
	      r->action = -1;  // delivered locally
	      packet_db.add(r);
	      // send an ACK packet
	      send_ACK(p);
	      // hand it over to the agent on the port it is addressed to
	      e->set_handler(Node->get_portmapper());
	      Scheduler.schedule(e);
	    }
	}
    }
  else
    {
      // packet needs forwarding
      // figure out how to send it, and send it on its way
      double s = akb.upave();   // get the average time that links are up
      // cout<<s<<endl;

      int have_route =  akb.findroute(Node->get_address(), 
				      h->dst_addr, h->last_hop);
      int state = get_state(s,have_route);
      
      // cout<<state<<endl;

      int action = my_policy.choose(state);
	 
      if((use_strategy[SHORTEST_PATH_STRATEGY])&&
	 (use_strategy[GOSSIP_STRATEGY]))
	{
	  if(action == 0)
	    gossip2(p,duplicate,0.95,3);
	  else
	    shortest_path(p,duplicate);
	}
      else
	if(use_strategy[GOSSIP_STRATEGY])
	  {
	    action = 0;
	    gossip2(p,duplicate,0.95,3);
	  }
	else
	  if(use_strategy[SHORTEST_PATH_STRATEGY])
	    {
	      action = 1;
	      shortest_path(p,duplicate);
	    }
	  else
	    if(use_strategy[FLOOD_STRATEGY])
	      {
		action = -1;
		flood(p,duplicate);
	      }

      // add it to our packet db
      if(!duplicate)
	{
	  packet_rec *r = new packet_rec;
	  r->ACK_received = 0;
	  r->h = *h;    // save the header in the packet record
	  // save the state variables
	  r->state = state;
	  // save the action chosen
	  r->action = action;
	  packet_db.add(r);
	}



      // the send method created a copy, so delete the original event
      delete e;
    }
}



void routing_agent::perform_purge()
{
  int state;
  int action;
  packet_list::head_tail *ht =
    packet_db.purge(Scheduler.time() - 2*PURGE_INTERVAL);
  packet_list *pl = ht->head;
  packet_list *pf = pl;
  packet_rec *p;
  int count = 0;
  while(pf != NULL)
    {
      // cout<<"deleting\n";
      pl = pl->get_next();
      //p = pf->get_data();
      //delete p;
      //pf->set_data(NULL);
      state = pf->get_data()->state;
      action =  pf->get_data()->action;
      if((action != -1)&&(pf->get_data()->ACK_received==0))
	if(learning && (pf->get_data()->h.type==data))
	  my_policy.learn(state,action,0.0);
      delete pf;
      pf = pl;
      count++;
    }
  delete ht;
  //cout<<"purged "<<count<<" records\n";}
}

void routing_agent::process_message(message_event *e)
{
  //static int timer_callcount = 0;
  //static int purge_callcount = 0;
  if(strcmp(e->get_message(),timer_msg)==0)
    {
      //  cout<<"timer="<<++timer_callcount<<endl;
      send_AKB_updates();
      Scheduler.schedule(Scheduler.time()+UPDATE_INTERVAL,
			 this,
			 timer_msg);
    }
  if(strcmp(e->get_message(),purge_msg)==0)
    {
      // cout<<"purge="<<++purge_callcount<<endl;
      // clear out old packets that we don't expect to see again.
      perform_purge();

      Scheduler.schedule(Scheduler.time()+PURGE_INTERVAL,
			 this,
			 purge_msg);
    }
  delete e;
}



void routing_agent::start()
{
  AKB_rec rec;

  int i,sum=0;

  if(use_strategy != NULL)
    for(i=0;i<NUM_STRATEGIES;i++)
      sum += use_strategy[i];
  if(sum < 1)
    {
      cerr<<"no routing strategies enabled\n";
      exit(1);
    }

  // populate our AKB with all of our local links;
  link_list *cl = Node->get_links();
  while(cl != NULL)
    {
      rec.src = cl->link->get_src()->get_address();
      rec.dst = cl->link->get_dst()->get_address();
      rec.type = AKB_Static;
      if(cl->link->get_status() == link_event::up)
	rec.active = 1;
      else
	rec.active = 0;
      rec.upat = 0.0;
      rec.downat = 0.0;
      rec.availability = 1.0;
      rec.cost = 1;
      rec.capacity = cl->link->get_rate();
      rec.delay = cl->link->get_delay();
      rec.errorrate = cl->link->get_error_rate();
      rec.qlength = cl->link->get_queue_size();
      rec.assertedby = rec.src;
      rec.ctime = Scheduler.time();
      rec.mtime = Scheduler.time();
      rec.updated = 1;
      rec.duty_cycle = cl->link->get_duty_cycle();

      akb.update(rec);

      rec.dst = cl->link->get_src()->get_address();
      rec.src = cl->link->get_dst()->get_address();

      akb.update(rec);

      cl=cl->next;
    }

}

void routing_agent::process_link_event(link_event *e)
{
  addr_t a,b;
  duplex_link *lnk = (duplex_link *)(e->get_link());
  AKB_rec *reca;
  AKB_rec *recb;
  double duty_cycle;

  // Update the local AKB
  a = lnk->get_nodea()->get_address();
  b = lnk->get_nodeb()->get_address();

  reca = akb.get(a,b);
  if(reca != NULL)
    {
      if(e->get_status() == link_event::up)
	reca->active = 1;
      else
	reca->active = 0;
      reca->updated = 1;
      // get the estimated duty cycle for the link
      reca->duty_cycle = lnk->get_duty_cycle();
      akb.update(*reca);
      delete reca;
    }

  recb = akb.get(b,a);
  if(recb != NULL)
    {
      if(e->get_status() == link_event::up)
	recb->active = 1;
      else
	recb->active = 0;
      recb->updated = 1;
      // get the estimated duty cycle for the link
      recb->duty_cycle = lnk->get_duty_cycle();
      akb.update(*recb);
      delete recb;
    }

  send_AKB_updates();

  delete e;
}

void routing_agent::handle(event *e)
{

  // handle events
// #ifdef DEBUG
//   cout<<"Routing agent event handler method called\n";
// #endif
  switch(e->type())
    {
    case event::packet:
      process_packet((packet_event *)e);
      break;
    case event::message:
      process_message((message_event *)e);
      break;
    case event::link:
      process_link_event((link_event *)e);
      break;
    default:
      cerr<<"Link event handler called with bad event type\n";
      exit(1);
    }

};

