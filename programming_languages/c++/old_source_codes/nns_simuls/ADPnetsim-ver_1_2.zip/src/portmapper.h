// -*- Mode: C++ -*-

#ifndef PORTMAPPER_H
#define PORTMAPPER_H

#include <sim_object.h>
#include <event.h>

/** Port map for a node.
 *
 * Each node has one of these.  Traffic sources and sinks
 * are attached to them on "ports."  The routing agent gets
 * all packets coming into the node.  Each packet is either forwarded
 * to other nodes (if the dest addr is not this node), handled directly
 * by the routing agent (if the dest port is ROUTING_PORT), or given
 * to the portmapper, which passes  them to the object on the
 * packet's dest port.  Ports are numbered starting at zero, and each
 * data agent that is added is given the next larger port number.
 */
class portmapper:public sim_object{
private:
  sim_object **ports;  /// An array of pointers, one for each port.
  int numports;        /// Current number of ports used.
public:
  portmapper();

  ~portmapper();

  /// Give the object a port and return the port number.
  int add(sim_object *obj);

  /// The event should aways be a packet_event. The portmapper
  /// handler passes the packet to the object on the packet's destination
  /// port.
  virtual void handle(event *e);

};

#endif

