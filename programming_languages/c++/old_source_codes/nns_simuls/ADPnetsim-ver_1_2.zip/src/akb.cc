// -*- Mode: C++ -*-
//
// Netsim - a network simulator
// Written by Larry D. Pyeatt
// Copyright 2005
// All rights reserved
//
// akb.cc - code for the AKB class

#include <akb.h>
#include <math.h>
#include <values.h>
#include <iostream>
using namespace std;

/*****************************************************************************
  Route cache
*****************************************************************************/


routecache::routecache()
{
  int i;
  for(i=0;i<CACHESIZE;i++)
    {
      entries[i].valid=0;
      entries[i].age=0;
    }
}

void routecache::add(addr_t dst, addr_t next_hop, int numhops)
{
  int i;
  int notfound=1;
  int oldest=0;
  // look for an empty cache slot, and age each valid cache entry.
  for(i=0;i<CACHESIZE;i++)
    {
      if(notfound && (!entries[i].valid))
	{
	  // found an empty slot, put the entry there
	  entries[i].dst=dst;
	  entries[i].next_hop = next_hop;
	  entries[i].valid = 1;
	  entries[i].age = 0;
	  entries[i].num_hops = numhops;
	  notfound=0;
	}
      else
	if(entries[i].valid)
	  {
	    entries[i].age++;
	    // keep track of oldest entry
	    if(entries[i].age>entries[oldest].age)
	      oldest=i;
	  }
    }
  if(notfound)
    {
      // cache is full.  replace oldest entry
      entries[oldest].dst=dst;
      entries[oldest].next_hop = next_hop;
      entries[oldest].valid = 1;
      entries[oldest].age = 0;
      entries[oldest].num_hops = numhops;
    }
}

cache_entry *routecache::find(addr_t dst)
{
  int i;
  for(i=0;i<CACHESIZE;i++)
    if(entries[i].valid && (entries[i].dst==dst))
      return &(entries[i]);
  return NULL;
}

void routecache::flush()
{
  int i;
  for(i=0;i<CACHESIZE;i++)
    entries[i].valid=0;
}


/******************************************************************************
  AKB
******************************************************************************/


/// Recursive routine for finding shortest route.
int AKB::findroute_recurse(int depth, addr_t src, addr_t dst,addr_t avoid)
{

  static int PRUNE_LEVEL;

  if(depth == 0)
    PRUNE_LEVEL=MAXINT;

  if(depth >= PRUNE_LEVEL)
    return 0;

  if(depth > 10)  // limit search to paths of length 10
    return 0;

  int bestlen=MAXINT;
  int nl;
  adjacency_list *d=l;
  while(d!=NULL)
    {
      if((!d->get_data()->used) &&
	 (d->get_data()->dst==dst) &&
	 (d->get_data()->active==1))
	 //&&
	 //(d->get_data()->src!=avoid))
	{
	  if(d->get_data()->src == src)
	    {
	      route_node = d->get_data()->dst;
	      PRUNE_LEVEL=depth;
	      return 1;
	    }
	  else
	    {
	      d->get_data()->used=1;
	      nl = findroute_recurse(depth+1,src,d->get_data()->src,avoid);
	      if((nl != 0) && (nl<=bestlen))
		{
		  bestlen=nl;
		}
	      d->get_data()->used=0;
	    }
	}
      d = d->get_next();
    }
  if(bestlen==MAXINT)
    return 0;
  return bestlen+1;
}

// find shortest route in number of hops. return number of hops
// and set route_node (the next hop from src)
int AKB::findroute(addr_t src, addr_t dst, addr_t avoid)
{
  // First, check to see if it is already in the route cache.
  struct cache_entry *cr=cache.find(dst);
  if(cr != NULL)
    {
      //cout << "  Found in cache\n";
      route_node = cr->next_hop;
      return cr->num_hops;
    }

  // If route was not found in the cache, then try to find a route.
  // clear out all of the used flags so we start fresh.
  adjacency_list *d=l;
  int cb = 0;
  while(d!=NULL)
    {
      d->get_data()->used=0;
      d = d->get_next();
      cb++;
    }

  int numhops = findroute_recurse(0,src,dst,avoid);

  // If a route was found, then add it to the cache
  if(numhops>0)
    cache.add(dst,route_node,numhops);

  return numhops;
}

int different(AKB_rec *a, AKB_rec *b)
{
  if(a->src != b->src) return 1;
  if(a->dst != b->dst) return 1;
  if(a->type != b->type) return 1;
  if(a->active != b->active) return 1;
  if(a->upat != b->upat) return 1;
  if(a->downat != b->downat) return 1;
  if(a->availability != b->availability) return 1;
  if(a->cost != b->cost) return 1;
  if(a->capacity != b->capacity) return 1;
  if(a->delay != b->delay) return 1;
  if(a->errorrate != b->errorrate) return 1;
  if(a->qlength != b->qlength) return 1;
  if(a->assertedby != b->assertedby) return 1;
  if(a->ctime != b->ctime) return 1;
  if(a->mtime != b->mtime) return 1;
  return 0;
}

AKB::~AKB()
{
  //cout<<"AKB destructor called\n";
  adjacency_list *d=l;
  while(l!=NULL)
    {
      l = l->get_next();
      delete d;
      d=l;
    }
}

void AKB::dump()
{
  adjacency_list *d=l;
  AKB_rec *r;
  while(d!=NULL)
    {
      r = d->get_data();
      cout<<r->src<<" "<<r->dst<<
	"  - active: "<<r->active<<endl;
      d = d->get_next();
    }
}

// get record for adjacency from source to dest
AKB_rec *AKB::get(addr_t source, addr_t dest){
  adjacency_list *d=l;
  AKB_rec *r;
  int done=0;
  while(d!=NULL)
    {
      r = d->get_data();
      if((r->src == source)&&(r->dst == dest))
	{
	  AKB_rec *ret = new AKB_rec;
	  *ret = *r;
	  return ret;
	}
      d = d->get_next();
    }
  return NULL;
}

// insert a new record into the AKB (or replace an existing record)
void AKB::update(AKB_rec &r)
{
  AKB_rec *c;

  adjacency_list *d = l;

  if(d != NULL)
    c = d->get_data();
  else
    c = NULL;

  while( (c!=NULL) && !((c->src == r.src) && (c->dst == r.dst)) )
    {
      d = d->get_next();
      if(d != NULL)
	c = d->get_data();
      else
	c = NULL;
    }

  if(c==NULL)
    {
      adjacency_list *x=new adjacency_list;
      x->set_data(r);
      x->set_next(l);
      l=x;
      x->get_data()->updated = 1;
    }
  else
    {
      if(different(c,&r))
	{
	  cache.flush();
	  memcpy(c, &r, sizeof(AKB_rec));
	  c->updated = 1;
	}
    }
}

// remove record from AKB
void AKB::remove(adjacency_list *l)
{
  cerr<<"AKB remove called ... does nothing\n";
}


double AKB::upave()
{
  adjacency_list *al;
  AKB_rec *curr;
  int count=0;
  double total = 0;
  al = l;
  while(al != NULL)
    {
      total += al->get_data()->duty_cycle;
      count++;
      al = al->get_next();
    }
  return total/count;
}




/******************************************************************************
  AKB payload
******************************************************************************/

AKB_payload::AKB_payload()
{
  data=NULL;
  numrec=NULL;
  records=NULL;
  size=0;
  curr = NULL;
  currnum = 0;
}

AKB_payload::AKB_payload(int count)
{
  construct(count);
}

AKB_payload::AKB_payload(char *dat, int sz)
{
  construct(dat, sz);
}

AKB_payload::~AKB_payload()
{
  if(data != NULL) delete[] data;
}


AKB_payload *AKB::get_update_payload(int get_all)
{
  int count=0;
  adjacency_list *al;
  AKB_rec *curr;
  AKB_payload *pl;

  al = l;
  while(al != NULL)
    {
      if((al->get_data()->updated)||get_all)
	count++;
      al = al->get_next();
    }

  pl = new AKB_payload(count);
  al = l;
  while(al != NULL)
    {
      if((al->get_data()->updated)||get_all)
	{
	  pl->add_rec(al->get_data());
	  al->get_data()->updated = 0;
	}
      al = al->get_next();
    }

  return pl;
}

void AKB_payload::construct(int count)
{
  // Have to make sure it is aligned properly, so allocate
  // it as structs. This wastes some space.  I could probably
  // allocate as chars, get 8 extra, and move the pointer
  // to the next 8-byte alignment, but then it would break
  // on machines that need 16 byte alignment.
  data = new AKB_rec[count+1];
  size = (count+1) * sizeof(AKB_rec);
  numrec = (int *)data;
  *numrec = count;
  records = data+1;
  curr = records;
  currnum = 0;
  //   unaligned code follows... broken on some machines
  //   size = sizeof(int) + count * sizeof(AKB_rec);
  //   data = new char[size];
  //   numrec = (int *)data;
  //   *numrec = count;
  //   records = (AKB_rec *)(numrec+1);
  //   curr = records;
  //   currnum = 0;
}

void AKB_payload::construct(char *dat, int sz)
{
  // Have to make sure it is aligned properly, so allocate
  // it as structs.  This wastes some space.
  size = sz;
  sz /= sizeof(AKB_rec);
  data = new AKB_rec[sz];
  memcpy(data,dat,size);
  numrec = (int *)data;
  records = data+1;
  curr = records;
  currnum = 0;
  //   unaligned code follows... broken on some machines
  //   size = sz;
  //   data = new char[size];
  //   memcpy(data,dat,size);
  //   numrec = (int *)data;
  //   records = (AKB_rec *)(numrec+1);
  //   curr = records;
  //   currnum = 0;
}

void AKB_payload::add_rec(AKB_rec *rec)
{
  *curr = *rec;
  curr++;
  currnum++;
}

int AKB_payload::payload_size()
{
  return size;
}

char *AKB_payload::payload_data()
{
  return (char *)data;
}

void AKB_payload::loop_init()
{
  curr = records; 
  currnum = 0;
}

AKB_rec *AKB_payload::next_rec()
{
  if((currnum++) < *numrec)
    return curr++;
  else 
    return NULL;
}

