
#include <stdlib.h>
#include <stdio.h>
#include <packet.h>

using namespace std;

int Packet::next_ID = 0;

Packet::Packet(){
  payload_size = 0;
  payload=NULL;
  header=NULL;
  unique_ID = next_ID++;
}

void Packet::set_header(packet_header *h)
{
  header = new packet_header;
  memcpy(header,h,sizeof(packet_header));
}

packet_header *Packet::get_header()
{
  return header;
}
  
void Packet::set_payload(void *p, int size)
{
  payload = new char[size];
  payload_size=size;
  header->payload_size = size;
  memcpy(payload, p, size);
}

void Packet::set_fake_payload(int size)
{
  payload = NULL;
  payload_size=size;
  header->payload_size = size;
}

void *Packet::get_payload()
{
  return payload;
}
 
int Packet::get_payload_size()
{
  return payload_size;
}

int Packet::size()
{
  return payload_size + sizeof(packet_header);
}

Packet::Packet(Packet &p)
{
  payload_size = p.payload_size;
  header = new packet_header;
  memcpy(header,p.header,sizeof(packet_header));
  if(p.payload == NULL)
    payload = NULL;
  else
    {
      payload = new char[payload_size];
      memcpy(payload,p.payload,payload_size);
    }
  unique_ID = next_ID++;
}

Packet::~Packet()
{
  if(header != NULL)
    delete header;
  if(payload != NULL)
    delete[] payload;
}
  
static void dumpheader(packet_header *h)
{
  printf("Destination: addr=%08x port=%08x\n",h->dst_addr,h->dst_port);
  printf("     Source: addr=%08x port=%08x\n",h->src_addr,h->src_port);
  printf("   Last hop: addr=%08x\n",h->last_hop);
  printf("seqnum=%d type=%d ttl=%d hopcount=%d payload_size=%d\n",
	 h->seqnum,h->type,h->ttl,h->hopcount,h->payload_size);
}

void Packet::dump()
{
  int i;
  dumpheader(header);
  printf("First 20 bytes of Payload:");
  if(payload == NULL)
    {
      printf("(fake payload)");
    }
  else
    {
      for(i=0;i<20;i++)
	printf(" %02x",payload[i]);
    }
  printf("\n");
}
