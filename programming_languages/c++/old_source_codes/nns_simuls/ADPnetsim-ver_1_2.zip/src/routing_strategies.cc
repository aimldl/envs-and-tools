// -*- Mode: C++ -*-

#include <sim_object.h>
#include <routing_agent.h>
#include <packet.h>
#include <event.h>
#include <scheduler.h>
#include <link.h>
#include <node.h>
#include <packet_list.h>


#define JITTER (drand48()-0.5)

/** \file 
 * \brief These are the routing strategies available to the routing agent.
 *
 * Routing strategies are in a separate file for convenience.  I considered
 * making a class for routing strategies as a subclass of routing
 * agent.  That would probably be a better approach in the long term,
 * but for now I am keeping it simple.
 *
 * All of the strategies take the packet as first argument.  The
 * second argument is a flag telling whether or not the packet is
 * a duplicate of another packet that was already sent out by this
 * node.  Some strategies may want to forward duplicates, while others
 * may avoid it.
 * 
 * Some of the strategies may be modified at compile time with the defines
 * at the top of the file.
*/

//#define FLOOD_DROP_WHEN_LINK_DOWN
#define FLOOD_NO_DUPLICATES

//#define GOSSIP_DROP_WHEN_LINK_DOWN
#define GOSSIP_NO_DUPLICATES

#define SHORTEST_PATH_DROP_WHEN_LINK_DOWN
#define SHORTEST_PATH_NO_DUPLICATES


/// A basic flood strategy.
/** Increment hop count by 1 and send packet down all links.
 */
void routing_agent::flood(Packet *p, int duplicate)
{
#ifdef FLOOD_NO_DUPLICATES
  if(duplicate)
    return;
#endif
  packet_event *pe;
  link_list *cl = Node->get_links();
  packet_header *h = p->get_header();
  
  int prev_last_hop = h->last_hop;
  h->last_hop = Node->get_address();
  // increase hopcount by the number of links we are sending it down
  // h->hopcount += Node->get_num_links()-1;
  // or increase by one
  h->hopcount++;
  
  // if the packet has expired, don't send it
  if(h->hopcount < h->ttl)
    while(cl != NULL)
      {
#ifdef FLOOD_DROP_WHEN_LINK_DOWN
	// don't send anything on links that are down
	if(cl->link->get_status() == link_event::up)
#endif
	  // don't send back where it came from
	  if(cl->link->get_dst()->get_address() != prev_last_hop)
	    {
	      pe = new packet_event(Scheduler.time(),cl->link);
	      pe->set_packet(new Packet(*p));
	      
	      // send packet down the link
	      Scheduler.schedule(pe);
	    }
	cl = cl->next;
      }
}


// Basic Gossip strategy.
/** Gossip2 strategy, as described in "Gossip-Based Ad Hoc Routing" by
 * Haas, Halpern, and Li.
 */
void routing_agent::gossip2(Packet *p, int duplicate, double prob, int range)
{
  // this is not right.  read the paper and change it
  packet_event *pe;
  link_list *cl = Node->get_links();
  packet_header *h = p->get_header();

  h->hopcount++;

  if(((h->hopcount <= range) || (drand48() <= prob))&&
#ifdef GOSSIP_NO_DUPLICATES
     !duplicate && 
#endif
     (h->hopcount <= h->ttl))
    {      
      int prev_last_hop = h->last_hop;
      h->last_hop = Node->get_address();
      // increase hopcount by the number of links we are sending it down
      // h->hopcount += Node->get_num_links()-1;
      // or increase by one
      
      // if the packet has expired, don't send it
      while(cl != NULL)
	{
#ifdef GOSSIP_DROP_WHEN_LINK_DOWN
	  // don't send anything if the link is down
	  if(cl->link->get_status() == link_event::up)
#endif
	    // don't send back where it came from
	    if(cl->link->get_dst()->get_address() != prev_last_hop)
	      {
		pe = new packet_event(Scheduler.time(),cl->link);
		pe->set_packet(new Packet(*p));
		
		// send packet down the link
		Scheduler.schedule(pe);
	      }
	  cl = cl->next;
	}
    }
}

/// Simple shortest path routing.
/** Sends packet one hop on the shortest path, as computed by
 * AKB.findroute().  It is assumed that AKB.findroute() has already
 * been used to make sure that a route exists.  Otherwise, bad things
 * could happen.
 */
void routing_agent::shortest_path(Packet *p, int duplicate)
{
#ifdef SHORTEST_PATH_NO_DUPLICATES
  if(duplicate)
    return;
#endif
  packet_event *pe;
  link_list *cl = Node->get_links();
  packet_header *h = p->get_header();
  int have_route;

  addr_t src = Node->get_address();
  addr_t dst = h->dst_addr;
  addr_t next_hop;

  // look for a route, and see if there is one.  (the route 
  // will be cached so that get_route will find it quickly.
  // this should be done by the handle_packet_event routine, in
  // order to find out which strategy to use, and should not be
  // done here.
  have_route =  akb.findroute(src, dst, h->last_hop);

  if(have_route)
    {
      h->last_hop = Node->get_address();
      next_hop = akb.get_route();
      //cout<<"On node "<<Node->get_address()<<"  Next hop = "<<next_hop<<endl;
      while((cl != NULL)&&
	    (cl->link->get_dst()->get_address() != next_hop)
	    )	
	cl = cl->next;
      if(cl != NULL)
	{
#ifdef SHORTEST_PATH_DROP_WHEN_LINK_DOWN
	  if(cl->link->get_status() == link_event::up)
#endif
	    {
	      h->last_hop = Node->get_address();
	      pe = new packet_event(Scheduler.time(),cl->link);
	      pe->set_packet(new Packet(*p));
	      // send packet down the link
	      Scheduler.schedule(pe);
	    }
	}
      else
	{
	  cout<<"Can't find matching link!\n";
	  exit(1);
	}
    }
  else
    {
      // cout<<"No route!!\n";
      // flood(p,duplicate);
    }
  
}






