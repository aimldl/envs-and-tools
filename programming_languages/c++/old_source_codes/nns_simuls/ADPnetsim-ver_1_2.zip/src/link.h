// -*- Mode: C++ -*-


#ifndef LINK_H
#define LINK_H

#include <iostream>
#include <event.h>

using namespace std;

class node;
class event;

/** A unidirectional communications link.
 *
 * The simplex_link class implements a link that carries
 * data packets from src_node to dest_node.  Packets are
 * stored on the send queue until it is their turn to be
 * transmitted.  The simplex_link class handles all of the
 * timing calculations for the packet as it is transmitted
 * and travels down the wire.
 *
 */
class simplex_link:public sim_object{
  
private:
  node *src_node,*dst_node;  ///< Pointers to the nodes this link connects.
  event_queue send_queue;    ///< FIFO queue of packets waiting to be sent.
  packet_event *transmitting;///< Pointer to the packet currently being transmitted.
  event_queue wire;          ///< FIFO queue of packets that are on the wire.

  link_event::link_status status; ///< Tracks whether the link is up or down.
  double delay;       ///< Time in seconds for one bit to travel down the wire.
  double data_rate;   ///< Number of bits/second that can be transmitted.
  int link_busy;      ///< Boolean telling whether or not we are transmitting.

  double duty_cycle;  ///< Percentage of time that the link is up (on average).
  double cycle_time;  ///< Average time in seconds for an up/down cycle.

  /// Handle a packet event.
  void process_packet(packet_event *e);
  /// Log a packet drop through the trace files.
  void log_drop(packet_event *e);
  /// Log receipt of a packet through the trace files.
  void log_receive(packet_event *e);
  /// Log sending of a packet through the trace files.
  void log_send(packet_event *e);
  /// Log packet entering send queue through the trace files.
  void log_enqueue(packet_event *e);
  /// Log packet leaving send queue through the trace files.
  void log_dequeue(packet_event *e);

public:
  
  void construct(node *s, node *d, double delay_, double data_rate_);
  simplex_link(node *s, node *d, double delay_, double data_rate_);
  virtual ~simplex_link();

  /// Event handler for simplex_link.
  virtual void handle(event *e);
  /// Print info on cout.
  virtual void dump();
  /// Set the link status to up or down.
  void set_status(link_event::link_status ls);
  /// Get the current link status.
  link_event::link_status get_status(){return status;}
  /// Get pointer to source node for this link.
  node *get_src(){return src_node;}
  /// Get pointer to destination node for this link.
  node *get_dst(){return dst_node;}
  /// Get the data rate for this link.
  double get_rate(){return data_rate;}
  /// Get the delay for this link.
  double get_delay(){return delay;}
  /// Get the bit error rate for this link. (not implemented)
  double get_error_rate(){return 0.0;}
  /// Find out how many packets are in the send queue.
  int get_queue_count(){
    return send_queue.count();
  }
  /// Find out how many packets are currently on the wire.
  int get_wire_count(){
    return wire.count()+link_busy;
  }
  /// Set the number of packets that can be in the send queue.
  void set_queue_size(int limit);
  /// Get the number of packets that can be in the send queue.
  int get_queue_size(){return send_queue.get_length();}

  /// Get the percentage of time that the link is up (on average).
  double get_duty_cycle(){ return duty_cycle; }
  /// Set the duty cycle in percent and cycle time in seconds for this link.
  void set_dynamics(double duty_cycle_, double cycle_time_);

};

/** A bidirectional communications link.
 *
 * The duplex_link class implements a link that carries
 * data packets bidirectionally between two nodes.  
 * A duplex_link is implemented as two simplex_links.
 * The duplex_link class manages simulation of the duty
 * cycle and tells its simplex_links when
 * to go up/down.
 */
class duplex_link:public sim_object{
 private:
   simplex_link *linka;  ///< Simplex link from nodea to nodeb
   simplex_link *linkb;  ///< Simplex link from nodeb to nodea
   
   node *nodea;  ///< One of the nodes connected by this link.
   node *nodeb;  ///< One of the nodes connected by this link.
   string orient;///< Orientation of the link (used for NAM trace).
   link_event::link_status status; ///< Tracks whether link is up or down.
   //double last_up;
   //double last_down;
   //double duty_cycle;
   double duty_cycle; ///< Percentage of time that the link is up (on average).
   double cycle_time; ///< Average time in seconds for an up/down cycle.
   int dynamics_undefined; 

   ///< Method to process a link event.
   void process_link_event(link_event *e);
   ///< Log the link status change through trace file.
   void log_change(char *newstate);

 public:

   duplex_link(node *a, node *b, double delay_, double data_rate_);
   duplex_link(){};
   virtual ~duplex_link();

   ///< Event handler.
   virtual void handle(event *e);
   ///< Print info on cout.
   virtual void dump();
   ///< Find total number of packets in send queues for this duplex_link.
   int get_queue_count(){
     return linka->get_queue_count()+linkb->get_queue_count();
   }
   ///< Find total number of packets on wire for this duplex_link.
   int get_wire_count(){
     return linka->get_wire_count()+linkb->get_wire_count();
   }

   ///< Initialize for beginning of simulation.
   virtual void start();

   /// Set the duty cycle and cycle time for the link dynamics.
   void set_dynamics(double duty_cycle_, double cycle_time_);
   /// Set the duty cycle for the link dynamics.
   double get_duty_cycle(){ return duty_cycle; }

   /// Get a pointer to one of the nodes connected by this link.
   node *get_nodea(){return nodea;}
   /// Get a pointer to one of the nodes connected by this link.
   node *get_nodeb(){return nodeb;}

   /// Set the send queue size for both simplex links.
   void set_queue_size(int limit);
   int get_queue_size(){return linka->get_queue_size();}

   /// Set the orientation of the link. (used by NAM trace)
   void set_orientation(string orientation);

 };





#endif
