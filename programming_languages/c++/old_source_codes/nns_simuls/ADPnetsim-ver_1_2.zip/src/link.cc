// -*- Mode: C++ -*-

#include <sim_object.h>
#include <packet.h>
#include <event.h>
#include <scheduler.h>
#include <link.h>
#include <routing_agent.h>
#include <node.h>
#include <trace.h>


#include <iostream>

using namespace std;


static char tmpstr[1024];



void simplex_link::construct(node *a, node *b, double delay_, double data_rate_)
{
  src_node=a;
  dst_node=b;
  status=link_event::up;
  delay = delay_;
  data_rate = data_rate_;
  link_busy = 0;
  transmitting=NULL;

}

void simplex_link::set_queue_size(int limit)
{
  send_queue.set_length(limit);
}

void duplex_link::set_queue_size(int limit)
{
  linka->set_queue_size(limit);
  linkb->set_queue_size(limit);
}

simplex_link::simplex_link(node *a, node *b, double delay_, double data_rate_)
{
  construct(a,b,delay_,data_rate_);
}

simplex_link::~simplex_link()
{
  //cout <<"simplex_link destructor called\n";
}


void simplex_link::log_send(packet_event *e)
{
  sprintf(tmpstr,"Time %lf: Packet %d from %d to %d sent\n",
	  Scheduler.time(),
	  e->get_packet()->get_ID(),
	  src_node->get_address(),
	  dst_node->get_address());
  trace.trace(tmpstr);

  sprintf(tmpstr,"h -t %lf -s %d -d %d -e %d -i %d\n",
	  Scheduler.time(),
	  src_node->get_address(),
	  dst_node->get_address(),
	  e->get_packet()->size(),
	  e->get_packet()->get_ID()
	  );
  trace.namtrace(tmpstr);
}

void simplex_link::log_receive(packet_event *e)
{
  sprintf(tmpstr,"Time %lf: Packet %d from %d to %d received\n",
	  Scheduler.time(),
	  e->get_packet()->get_ID(),
	  src_node->get_address(),
	  dst_node->get_address());
  trace.trace(tmpstr);

  sprintf(tmpstr,"r -t %lf -s %d -d %d -e %d -i %d\n",
	  Scheduler.time(),
	  src_node->get_address(),
	  dst_node->get_address(),
	  e->get_packet()->size(),
	  e->get_packet()->get_ID()
	  );
  trace.namtrace(tmpstr);
}

void simplex_link::log_drop(packet_event *e)
{
  sprintf(tmpstr,"Time %lf: Packet %d from %d to %d dropped\n",
	  Scheduler.time(),
	  e->get_packet()->get_ID(),
	  src_node->get_address(),
	  dst_node->get_address());
  trace.trace(tmpstr);

  sprintf(tmpstr,"d -t %lf -s %d -d %d -e %d -i %d\n",
	  Scheduler.time(),
	  src_node->get_address(),
	  dst_node->get_address(),
	  e->get_packet()->size(),
	  e->get_packet()->get_ID()
	  );
  trace.namtrace(tmpstr);
}


void simplex_link::log_enqueue(packet_event *e)
{
  sprintf(tmpstr,"Time %lf: Packet %d from %d to %d entering packet queue\n",
	  Scheduler.time(),
	  e->get_packet()->get_ID(),
	  src_node->get_address(),
	  dst_node->get_address());
  trace.trace(tmpstr);

  //  sprintf(tmpstr,"d -t %lf -s %d -d %d -e %d -i %d\n",
  sprintf(tmpstr,"+ -t %lf -s %d -d %d -i %d\n",
	  Scheduler.time(),
	  src_node->get_address(),
	  dst_node->get_address(),
	  e->get_packet()->size(),
	  e->get_packet()->get_ID()
	  );
  trace.namtrace(tmpstr);
}

void simplex_link::log_dequeue(packet_event *e)
{
  sprintf(tmpstr,"Time %lf: Packet %d from %d to %d leaving packet queue\n",
	  Scheduler.time(),
	  e->get_packet()->get_ID(),
	  src_node->get_address(),
	  dst_node->get_address());
  trace.trace(tmpstr);

  //  sprintf(tmpstr,"d -t %lf -s %d -d %d -e %d -i %d\n",
  sprintf(tmpstr,"- -t %lf -s %d -d %d -i %d\n",
	  Scheduler.time(),
	  src_node->get_address(),
	  dst_node->get_address(),
	  e->get_packet()->size(),
	  e->get_packet()->get_ID()
	  );
  trace.namtrace(tmpstr);
}

void simplex_link::process_packet(packet_event *e)
{
  packet_event *ne;
  packet_event *drop;
  Packet *p;

  // if it is the packet we are currently transmitting
  switch(e->get_status())
    {
    case packet_event::xmit:
      // the packet just finished transmitting
      // change it's status to on_wire
      e->set_status(packet_event::on_wire);
      // set the time that it will finish being received
      e->set_time(Scheduler.time()+delay);
      // and give it back to the scheduler
      e->set_handler(this);
      Scheduler.schedule(e);
      // keep track of it in case we need to dequeue it (it gets dropped)
      wire.add(e);
      link_busy = 0;
      transmitting = NULL;
      // start transmitting next packet in queue;
      ne = (packet_event *)send_queue.get();
      if(ne != NULL)
	{
	  log_dequeue(ne);
	  ne->set_status(packet_event::xmit);
	  ne->set_time(Scheduler.time()+
		       (ne->get_packet()->size())*8/data_rate);
	  ne->set_handler(this);
	  log_send(ne);
	  Scheduler.schedule(ne);
	  link_busy = 1;
	  transmitting = ne;
	}
      break;
    case packet_event::on_wire:
      // pull it out of the on_wire queue
      // if it is not on our wire, then it was dropped.
      if(wire.remove(e))
	{
	  // cout<<"packet on wire\n";
	  // pull it of the wire queue
	  // ne = (packet_event *)wire.get();
	  // change it's status to unknown
	  e->set_status(packet_event::unknown);
	  // set it for immediate processing
	  e->set_time(Scheduler.time());
	  // set the node that just got it
	  log_receive(e);
	  // log it
	  e->set_handler(dst_node);
	  // and give it back to the scheduler
	  Scheduler.schedule(e);
	}
      else

	{
#ifdef DEBUG
  	  cout<<"Packet "<<e<< " ("<<
  	    e->get_packet()->get_header()->src_addr<<","<<
  	    e->get_packet()->get_header()->dst_addr<<")  NOT ON WIRE\n";
#endif
// 	  cout<<"event for packet "<< e <<" ("<<
// 	    e->get_packet()->get_header()->src_addr<<","<<
// 	    e->get_packet()->get_header()->dst_addr<<") "<<
// 	    " not at front of wire!\n";
	  // It was logged when the link went down.
// 	  p = e->get_packet();
// 	  if(p != NULL)
// 	    delete p;
	  delete e;
	}
      break;
    default:
      // if the link is down, or we are busy transmitting another packet,
      // put it in the queue (it may get dropped)
      if((status == link_event::down)||(link_busy))
	{
	  //cout<<"Adding to send queue\n";
	  e->set_status(packet_event::waiting);
	  log_enqueue(e);
	  if((drop = (packet_event *)send_queue.add(e)) != 0)
	    {
	      log_drop(drop);
	      delete drop;
	    }
	}
      else
	{
	  //cout<<"transmitting now\n";
	  link_busy = 1;
	  e->set_status(packet_event::xmit);
	  e->set_time(Scheduler.time()+
		      (e->get_packet()->size())*8/data_rate);
	  e->set_handler(this);
	  log_send(e);
	  Scheduler.schedule(e);
	  // cout<<"XMIT_TIME = "<<e->get_time()-Scheduler.time()<<endl;
	  // keep track of packets on the wire, we may have to drop them
	  // if the link goes down
	  transmitting = e;
	}
    }

}

void simplex_link::set_status(link_event::link_status ls)
{
  status = ls;
  if(status == link_event::down)
    {
      // If the link goes down, drop whatever is being transmitted and
      // whatever is on the wire.
      // Pull all packets off the wire queue and lose the
      // pointers (the scheduler still has the pointers, and the
      // events will come in on schedule)  When the events come in,
      // the event handler will check to see if they are on the wire,
      // and just ignore them if we don't have them on the wire.
      if(link_busy)
	{
	  // change the status of the packet we are transmitting,
	  // so that the event handler will only have to check
	  // packets that are on_wire
	  transmitting->set_status(packet_event::on_wire);	  
	  log_drop(transmitting);
#ifdef DEBUG
	  cout<<"Packet "<< transmitting <<" ("<<
	    transmitting->get_packet()->get_header()->src_addr<<","<<
	    transmitting->get_packet()->get_header()->dst_addr<<") "<<
	    " dropped due to link going down while being transmitted\n";
#endif
	}
      while((transmitting = (packet_event *)wire.get())!=NULL)
	{
	  log_drop(transmitting);
#ifdef DEBUG
 	  cout<<"Packet "<<transmitting<< " ("<<
 	    transmitting->get_packet()->get_header()->src_addr<<","<<
 	    transmitting->get_packet()->get_header()->dst_addr<<") "<<
 	    " dropped due to link going down while on wire\n";
#endif
	}
      // transmitting should now be NULL, and wire empty
      link_busy = 0;
    }
  else
    {
      // if the link comes up, send whatever is in the send queue;
      if((transmitting = (packet_event *)send_queue.get()) != NULL)
	{
	  link_busy = 1;
	  transmitting->set_status(packet_event::xmit);
	  transmitting->set_handler(this);
	  transmitting->set_time(Scheduler.time()+
				 (transmitting->get_packet()->size())*
				 8/data_rate);
	  Scheduler.schedule(transmitting);
	}
    }
}


void simplex_link::handle(event *e)
{
  // handle events
  //cout<<"Simplex link event handler method called\n";
  switch(e->type())
    {
    case event::packet:   // find status of packet, and move it along
      // start transmitting the next packet in our queue
      process_packet((packet_event *)e);
      break;
      //case event::link:   // change status of link
      //cout<<"It's a link event\n";
      //break;
      //case event::message:  // process a message 
      // change our status. 
      // drop all packets currently on wire or in transmission.
      // notify the nodes that this link is connected to
      // schedule the next link_up event
      //cout<<"It's a message event\n";
      //break;
    default:
      cerr<<"Simplex link event handler called with bad event type\n";
      cerr<<e->type()<<endl;
      exit(1);
    }
}


void simplex_link::dump()
{
  sim_object::dump();
  printf("Simplex link\n");
}

void simplex_link::set_dynamics(double duty_cycle_, double cycle_time_)
{
  duty_cycle = duty_cycle_;
  cycle_time = cycle_time_;
}

  
duplex_link::duplex_link(node *a, node *b, double delay_, double data_rate_)
{
  nodea=a; 
  nodeb=b; 
  status=link_event::up; 
  linka=new simplex_link(a,b,delay_,data_rate_);
  linkb=new simplex_link(b,a,delay_,data_rate_);
  nodea->add_link(linka);
  nodeb->add_link(linkb);
  orient = "";
  dynamics_undefined = 1;
}

void duplex_link::set_orientation(string orientation)
{
  orient = orientation;
}

duplex_link::~duplex_link()
{
  //cout <<"duplex_link destructor called\n";
}


void duplex_link::set_dynamics(double duty_cycle_, double cycle_time_)
{
  duty_cycle = duty_cycle_;
  cycle_time = cycle_time_;
  if(duty_cycle < 1.0)
    if(dynamics_undefined)
      // set up Random Number generator for jittering duty cycle and cycle time
      {
	double offset = drand48()*cycle_time*duty_cycle+Scheduler.time();
	link_event *le=new link_event(offset,this);
	le->set_down();
	le->set_link(this);
	Scheduler.schedule(le);
	dynamics_undefined = 0;
      }
  linka->set_dynamics(duty_cycle_,cycle_time_);
  linkb->set_dynamics(duty_cycle_,cycle_time_);
}

#define JITTER (drand48()-0.5)

void duplex_link::log_change(char *newstate)
{
  sprintf(tmpstr,"Time %lf: Link between %d and %d going %s\n",
	  Scheduler.time(),
	  nodea->get_address(),
	  nodeb->get_address(),newstate);
  trace.trace(tmpstr);

  sprintf(tmpstr,"l -t %lf -s %d -d %d -S %s\n",
	  Scheduler.time(),
	  nodea->get_address(),
	  nodeb->get_address(),
	  newstate);
  trace.namtrace(tmpstr);
}

void duplex_link::process_link_event(link_event *e)
{
  double next_event;

// #ifdef DEBUG
//   if(e->get_status() == link_event::up)
//     cout<<"Time: "<< Scheduler.time()<<" link "<< get_ID() <<" coming up\n";
//   else
//     cout<<"Time: "<< Scheduler.time()<<" link "<< get_ID() <<" going down\n";
// #endif

  // set the status on the simplex links
  linka->set_status(e->get_status());
  linkb->set_status(e->get_status());

  // generate two new link events to notify the nodes involved 

  link_event *eventa = new link_event(Scheduler.time(),nodea);
  link_event *eventb = new link_event(Scheduler.time(),nodeb);

  eventa->set_link(e->get_link());
  eventb->set_link(e->get_link());

  if(e->get_status() == link_event::up)
    {
      eventa->set_up();
      eventb->set_up();
      log_change("UP");
    }
  else
    {
      eventa->set_down();
      eventb->set_down();
      log_change("DOWN");
    }
 
  Scheduler.schedule(eventa);
  Scheduler.schedule(eventb);

  // schedule next link change     
  if(e->get_status() == link_event::up)
    {
      next_event = duty_cycle * cycle_time;
      next_event += next_event * JITTER;
      e->set_down();      
    }
  else
    {
      next_event = (1-duty_cycle) * cycle_time;
      next_event += next_event * JITTER;
      e->set_up();
    }

  e->set_time(Scheduler.time() + next_event);
  
  Scheduler.schedule(e);
}

void duplex_link::handle(event *e)
{
  // handle events
  //cout<<"Link event handler method called\n";
  switch(e->type())
    {
    case event::packet:   // find status of packet, and move it along
      // start transmitting the next packet in our queue
      break;
    case event::link:   // change status of link
      // change the link status
      process_link_event((link_event *)e);
      break;
    case event::message:  // process a message 
      cerr<<"duplex_link::handle() called with message event type\n";
      break;
    default:
      cerr<<"Link event handler called with bad event type\n";
      exit(1);
    }
}

void duplex_link::dump()
{
  sim_object::dump();
  printf("Duplex link\n");
}


void duplex_link::start()
{
  string ostr;
  sprintf(tmpstr,"Link between %d and %d\n",nodea->get_address(),
	  nodeb->get_address());
  trace.trace(tmpstr);

  if(orient == "")
    ostr = "";
  else
    ostr = "-h 20 -o " + orient; // give it 20 length, or it looks bad

  sprintf(tmpstr,"l -t * -s %d -d %d -S UP %s -r %lf -D %lf\n",
	  nodea->get_address(),
	  nodeb->get_address(),
	  ostr.c_str(),
	  linka->get_rate(),
	  linka->get_delay());
  trace.namtrace(tmpstr);
}
