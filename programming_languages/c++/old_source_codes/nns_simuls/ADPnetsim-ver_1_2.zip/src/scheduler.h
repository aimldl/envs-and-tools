// -*- Mode: C++ -*-


#ifndef SCHEDULER_H
#define SCHEDULER_H


#include <event.h>

/** The scheduler manages the event queue for the simulation.
 * 
 * The event queue is a priority queue of events.  Events may be
 * created at any time during (or before) the simulation.  The entity
 * that creates an event must set the event handler and the event time.
 * After that, the event can be passed to the scheduler, which will put
 * it on the priority queue.  When the proper time comes, the event is
 * taken from the front of the queue and given to the handler.
 *
 * The simulation has one global scheduler that manages the event queue.
 */
class scheduler{
private:
  event_priority_queue_stl queue; ///< STL priority queue implementation.
  double sim_time;                ///< Current simulation time.
  double stop_time;               ///< Time that simulation should end.
public:
  
  scheduler();

  ~scheduler();

  /// Set the time that simulation should end.
  void stop_at(double s_time){stop_time=s_time;}

  /// Get the current simulation time.
  double time(){return sim_time;}

  /// Add an event to the queue.
  void schedule(event *e);

  /// A convenience method for sending message events.
  void schedule(double tm, sim_object *targ, char *cmd);

  /// Pull first event of queue and pass it to its handler.
  ///
  /// Returns 0 if there are no events in the queue.  Returns 1 otherwise.
  int dispatch();

  /// Delete all events in the queue.
  void flush();

  /// Print message on cout, telling how many events are in the queue.
  void report(){
    cout<<"there are "<<queue.size()<<" events in the scheduler queue\n";
  }

};

/// The global static instance of the scheduler class.
///
/// The Scheduler can be accessed anywhere in the simulation, to
/// allow events to be scheduled at any time.
extern scheduler Scheduler;

#endif
