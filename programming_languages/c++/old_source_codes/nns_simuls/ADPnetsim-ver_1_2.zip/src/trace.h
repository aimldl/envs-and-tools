// -*- Mode: C++ -*-

#ifndef TRACE_H
#define TRACE_H

#include <stdlib.h>
#include <string>

/** An object to implement tracing of the simulation.
 * 
 * A Trace object called trace is automatically created for the simulation.
 * The Trace object can create NAM trace file, and/or our own, simpler, format.
 * By default, no tracing is done, but you can turn on tracing simply by
 * telling the trace object what files to write to.
 */
class Trace{
private:
  FILE *tf;  ///< Pointer to the simple trace file.
  FILE *nam; ///< Pointer to the NAM trace file.

  /// Convenience routine to write and check for error.
  /// If the file is not open, it just returns without doing anything.
  void writefile(FILE *f,char *s)
  {
    if(f != NULL)
      {
	int stl = strlen(s);
	int numwrote = fwrite(s,1,stl,f);
	if(stl != numwrote)
	  {
	    perror("Trace::writefile cannot write to file: ");
	    exit(1);
	  }
      }
  }

public:
  Trace(){
    tf = nam = NULL;
  }

  ~Trace(){
    if(tf != NULL)
      if(fclose(tf) != 0)
	perror("Error closing trace file: ");
	
    if(nam != NULL)
      if(fclose(nam) != 0)
	perror("Error closing nam file: ");
  }

  /// Open a NAM trace file and enable writing to it.
  void namfile(char *filename){
    nam = fopen(filename,"w");
    if(nam == NULL)
      {
	perror("Unable to open nam file for output: ");
	exit(1);
      }
    namtrace("V -t * -v 1.0a5 -a 0\n");
  }

  /// Open a simple trace file and enable writing to it.
  void tracefile(char *filename){
    tf = fopen(filename,"w");
    if(tf == NULL)
      {
	perror("Unable to open trace file for output: ");
	exit(1);
      }
  }

  /// Write a string to the trace file, if it is open.
  void trace(char *s)
  {
    writefile(tf,s);
  }

  /// Write a string to the NAM trace file, if it is open.
  void namtrace(char *s)
  {
    writefile(nam,s);
  }

};


extern Trace trace;

#endif
