// -*- Mode: C++ -*-

#ifndef PACKET_H
#define PACKET_H

#include <stdlib.h>
#include <string.h>

/// Definition of the addr_t data type.
typedef unsigned int addr_t;
/// Definition of the port_t data type.
typedef unsigned int port_t;

/// A list of the types of packets that we support.
typedef enum {unknown,ack,data,routing_data,routing_ack} packet_type;

/// Definition of a packet header.
typedef struct{
  addr_t dst_addr;
  port_t dst_port;
  addr_t src_addr;
  port_t src_port;
  unsigned int seqnum;
  packet_type type;
  addr_t last_hop;
  unsigned int ttl;
  unsigned int hopcount;
  unsigned int payload_size;
}packet_header;

/** Definition of a packet of data. 
 * 
 * This is the actual payload and header of a packet.  Not to be confused
 * with a packet_event, which tracks events regarding this header and payload.
 * most packets will have an associated event.
 */
class Packet{
private:
  packet_header *header;  ///< The packet header.
  char *payload;          ///< The payload. (may be NULL)
  int payload_size;       ///< Size of the payload.
  int unique_ID;          ///< Unique ID for the packet. (not in the header)
  static int next_ID;     ///< Static int for assigning unique IDs.
public:
  Packet();
  Packet(Packet &p);
  ~Packet();

  /// Set the pointer to the packet's header data.
  void set_header(packet_header *h);
  /// Get a pointer to the packet's header data.
  packet_header *get_header();
  
  /// Set the pointer to the packet's payload data.
  void set_payload(void *p, int size);
  /// Create a "fake" payload.
  void set_fake_payload(int size);
  /// Get pointer to the payload.
  void *get_payload();
  /// Get size of the payload.
  int get_payload_size();

  /// Get total size of the packet.
  int size();

  /// Get the unique ID of the packet.
  int get_ID(){return unique_ID;}

  /// Print info to cout.
  void dump();
};

#endif
