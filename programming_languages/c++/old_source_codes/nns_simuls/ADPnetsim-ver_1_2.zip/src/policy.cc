#include <pthread.h>
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <math.h>
#include <policy.h>
#include <assert.h>

using namespace std;



int policy::choose(double dc)
{
  int maxpos = 0;
  double maxval = 0.0;
  double val;
  int i;
  double  ddcs[NUM_DC];
  i = 0;
  while((Q[0][i].state < dc)&&(i<NUM_DC))
    i++;
  int top = i;
  int bottom = i-1;
  if(i==NUM_DC)
    {
      top--;
      bottom--;
    }
  if(i==0)
    {
      top=i;
      bottom=i;
    }

  for(i=0;i<NUM_PROT;i++)
    {
      val = (Q[i][top].value-Q[i][bottom].value)/(Q[i][top].state-Q[i][bottom].state);
      val *= dc - Q[i][bottom].state;
      val += Q[i][bottom].state;
      if(val > maxval)
	{
	  maxpos = i;
	  maxval = val;
	}
    }
  return maxpos;
}


policy::policy()
{
  int count;
  int i,j;
  // read in the policy from file
  for(i=0;i<NUM_PROT;i++)
    {
      FILE *of;
      char filename[100];
      sprintf(filename,"policy.%d",i);
      if((of=fopen(filename,"r"))==NULL)
	{
	  perror("unable to open policy file");
	  exit(1);
	}
      for(j=0;j<NUM_DC;j++)
	{
	  fscanf(of,"%lf %lf\n",&(Q[i][j].state),&(Q[i][j].value));
	}
      fclose(of);
    }
}


#define OPTIMISTIC


void table_policy::allocate_table()
{
  int i,j;
  Q = new double *[nstates];
  for(i=0;i<nstates;i++)
    {
      Q[i] = new double[nactions];
      for(j=0;j<nactions;j++)
#ifdef OPTIMISTIC
	Q[i][j] = 1.0;
#else
	Q[i][j] = 0.0;
#endif
    }
}

table_policy::table_policy(int numstates, int numactions)
{
  nstates = numstates;
  nactions = numactions;
  alpha = 0.001;
  epsilon = 0.01;
  allocate_table();
}


void table_policy::delete_table()
{
  int i;  
  for(i=0;i<nstates;i++)
    delete[] Q[i];
  delete[] Q;
}


table_policy::~table_policy()
{
  delete_table();
}

/** Chooses an action from the policy, with some randomness,
 *  using the \f$\epsilon\f$-greedy method.
 */
int table_policy::choose(int state)
{
  int i,max=0;
  double maxval = Q[state][0];

  //cout<<state<<endl;
  assert((state < nstates) && (state >= 0));
  if(drand48() < epsilon)
    return lrand48() % nactions;
  
  for(i=1;i<nactions;i++)
    if(Q[state][i] > maxval)
      {
	maxval = Q[state][i];
	max = i;
      }
  return max;
}


/** Well, the less said about this, the better.  It is a very
 * simple learning algorithm.  The formula is 
 *\f[ Q_s^a(t+1) = (1-\alpha)Q_s^a(t) + \alpha R \f]
 * where \f$R\f$ is the reward at time \f$t\f$ and \f$\alpha\f$
 * is the learning rate.
 * Embarrassingly simple.
 */
void table_policy::learn(int state, int action, double reward)
{
  assert((state < nstates) && (state >= 0));
  assert((action < nactions) && (action >= 0));
  Q[state][action] = ((1.0-alpha)*Q[state][action]) + (alpha * reward);
}


void table_policy::save(char *filename)
{
  FILE *f;
  int i;
  if((f = fopen(filename,"w"))==NULL)
    {
      perror("table policy: error opening file");
      exit(1);
    }
  if(fwrite(&nstates,sizeof(int),1,f) != 1)
    {
      perror("table policy: error writing file");
      exit(1);
    }
  if(fwrite(&nactions,sizeof(int),1,f) != 1)
    {
      perror("table policy: error writing file");
      exit(1);
    }
  if(fwrite(&alpha,sizeof(double),1,f) != 1)
    {
      perror("table policy: error writing file");
      exit(1);
    }
  if(fwrite(&epsilon,sizeof(double),1,f) != 1)
    {
      perror("table policy: error writing file");
      exit(1);
    }
  for(i=0;i<nstates;i++)
    if(fwrite(Q[i],sizeof(double),nactions,f) != nactions)
      {
	perror("table policy: error writing file");
	exit(1);
      }
  fclose(f);
}

void table_policy::restore(char *filename)
{
  FILE *f;
  int i;
  if((f = fopen(filename,"r"))==NULL)
    {
      //cout<<"table_policy: No file to load\n";
      perror("table policy: error opening policy file");
      return;
      //exit(1);
    }
  delete_table();
  if(fread(&nstates,sizeof(int),1,f) != 1)
    {
      perror("table policy: error reading file");
      exit(1);
    }
  if(fread(&nactions,sizeof(int),1,f) != 1)
    {
      perror("table policy: error reading file");
      exit(1);
    }
  if(fread(&alpha,sizeof(double),1,f) != 1)
    {
      perror("table policy: error reading file");
      exit(1);
    }
  if(fread(&epsilon,sizeof(double),1,f) != 1)
    {
      perror("table policy: error reading file");
      exit(1);
    }
  allocate_table();
  for(i=0;i<nstates;i++)
    if(fread(Q[i],sizeof(double),nactions,f) != nactions)
      {
	perror("table policy: error reading file");
	exit(1);
      }
  fclose(f);
}


void table_policy::print()
{
  int i,j;
  for(i=0;i<nstates;i++)
    {
      cout<<"State "<<i<<" :";
      for(j=0;j<nactions;j++)
	cout<<" "<<Q[i][j];
      cout<<endl;
    }
}
