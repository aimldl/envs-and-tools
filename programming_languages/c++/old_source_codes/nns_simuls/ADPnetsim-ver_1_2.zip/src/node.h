// -*- Mode: C++ -*-


#ifndef NODE_H
#define NODE_H


#include <routing_agent.h>
#include <sim_object.h>
#include <packet.h>
#include <portmapper.h>
#include <data_agent.h>

using namespace std;

class routing_agent;
class link_list;
class duplex_link;
class simplex_link;

class node;

/** A list of the links that are connected to a node.
 *
 * Each node keeps a list of the outgoing links that are connected to
 * it in a link_list structure.
 */
class link_list{
public:
  simplex_link *link;  ///< Pointer to an outgoing link.
  node *neighbor;      ///< Pointer to the node that this link connects us to.
  link_list *next;     ///< Next outgoing link in our list.
};

/** A communications node in the network.
 *
 * The network is made of nodes and links.  The node class defines
 * a network node.  Each node contains a routing agent, a list
 * of outgoing links, and a portmapper.
 */
class node:public sim_object{
private:
  routing_agent *ragent;  ///< Routing agent for the node.
  static addr_t last_address;  ///< Used for assigning unique address to nodes.
  addr_t address;        ///< Address of this node.
  link_list *links;  ///< Rist of outgoing links for this node.
  int num_links;     ///< Number of outgoing links for this node.
  portmapper *ports;  ///< Portmapper for handling incoming packets.

public:

  node();
  virtual ~node();

  /// Get the address for this node.
  addr_t get_address(){return address;}

  /// Set the address for this node.
  void set_address(addr_t addr){address=addr;}

  /// Add an outgoing link to this node.
  void add_link(simplex_link *l);

  /// Turn learning on (l=1) or off (l=0).
  void learn(int l){ragent->learn(l);}

  /// Get the list of outgoing links for this node.
  link_list *get_links(){return links;}
  /// Find out how many outgoing links this node has.
  int get_num_links(){return num_links;}

  /// Event handler.
  virtual void handle(event *e);

  /// Print information to cout.
  virtual void dump();

  /// Add a data agent (source or sink) to this node.
  int install_agent(data_agent *a);

  /// Get a pointer to the portmapper for this node.
  portmapper *get_portmapper(){return ports;}

};


#endif
