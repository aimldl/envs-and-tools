// -*- Mode: C++ -*-


#ifndef SIM_OBJECT_H
#define SIM_OBJECT_H


/** \mainpage ADPnetsim
    
    \section intro_sec Introduction

    ADPnetsim is a simple network simulator originally developed for
    the purpose of conducting research in the application of
    Approximate Dynamic Programming (ADP) techniques to routing in
    Disruption Tolerant Networks (DsTN).  ADPnetsim is similar to, and
    was inspired by, NS2, a very large and feature rich network
    simulator.  The goal of NS2 is to provide a very flexible and
    simulation environment.  The goal of ADPnetsim is to provide high
    performance by including only the simulation elements that are
    necessary for our current research.  If you are familiar with
    NS2, then you should have little difficulty in learning ADPnetsim.

    \section overview_sec Overview

    ADPnetsim, like NS2, is a discrete event simulator.  This means
    that simulation is driven by events on a queue.  During
    initialization, some events are created and placed on the event
    queue.  When simulation begins, the first event is taken from the
    queue, processed, and discarded.  During processing of an event,
    other events may be created and placed on the queue.  When the
    simulator finishes procesing an event, it takes the next event
    from the queue and processes it.  This continues until there are
    no more events on the queue, or until the next event has an event
    time that is greater than a pre-set maximum. In NS2, there is a
    single instance of the Scheduler object which takes care of
    managing the event queue.

    The best way to think of ADPnetsim is that it is simply a library
    of object classes.  To set up a simulation, you write a program
    which uses that library. This is similar to the NS2 approach.  The
    major difference being that, in NS2, the program you write is in
    oTCl, while in ADPnetsim, you write in C++.  We are currently working
    an oTCl bindings for ADPnetsim, but that work is far from complete.

    In learning to use ADPnetsim, your major task is to learn about
    the objects that you will need to use in creating a simulation.
    In this section, we will provied an example to get you started.
    In the remaining sections of this manual, the objects are
    explained in detail.  Once you understand the example in this
    section, you should refer to the remaining documentation to find
    additional object methods that are not covered here.

    The main program should be divided into the following sections:
    -# Simulator Initialization
    -# Creation of nodes and links
    -# Creation of data sources and sinks
    -# Running the simulator
    -# Termination and clean-up
    
    The following sections explain this in more detail.

    \subsection si_sect Simulator Initialization

    Simulator initialization consists of seeding the random number
    generators, optionally setting up trace files, and specifying
    which routing strategies are enabled.  The following code segment
    shows a typical sequence:
    \code
    // Initialize random number generators
    time_t tm;
    srandom(time(&tm));
    srand48(time(&tm));

    // SET the trace files for our format and for NAM format
    trace.tracefile("netsim.trace");
    trace.namfile("netsim.nam");

    // TELL routing agent which strategies are enabled
    routing_agent::set_strategy(SHORTEST_PATH_STRATEGY,1);
    routing_agent::set_strategy(GOSSIP_STRATEGY,0);
    routing_agent::set_strategy(FLOOD_STRATEGY,0);
    // only shortest path (Link State) is enabled
    \endcode

    \subsection nl_sect Creation of Nodes and Links

    The next section of code shows how to set up a mesh of
    nodes and links.  The number of nodes in the mesh is determined
    by MESHSIZE.  If you are familiar with NS2, you should recognize
    some similarity.

    \code
    // DECLARE the nodes, links, traffic sources, and traffic sinks
    node *nodes[MESHSIZE][MESHSIZE];
    duplex_link *links[2][(MESHSIZE)][(MESHSIZE)-1];

    // Create Nodes
    for(i=0;i<MESHSIZE;i++)
      for(j=0;j<MESHSIZE;j++)
        {
          nodes[i][j] = new node;
          // disable learning on nodes
          nodes[i][j]->learn(0);  
        }

    // Create Vertical Links
    for(i=0;i<MESHSIZE-1;i++)
      for(j=0;j<MESHSIZE;j++)
        {
          links[0][j][i]=new duplex_link(nodes[i][j],nodes[i+1][j],DELAY,DR);
          links[0][j][i]->set_dynamics(DUTY_CYCLE,CYCLE_TIME);
          links[0][j][i]->set_queue_size(QUEUE_SIZE);
          links[0][j][i]->set_orientation("down");
        }

    // Create Horizontal Links
    for(i=0;i<MESHSIZE;i++)
      for(j=0;j<MESHSIZE-1;j++)
        {
          links[1][i][j]=new duplex_link(nodes[i][j],nodes[i][j+1],DELAY,DR);
          links[1][i][j]->set_dynamics(DUTY_CYCLE,CYCLE_TIME);
          links[1][i][j]->set_queue_size(QUEUE_SIZE);
          links[1][i][j]->set_orientation("right");
        }
    \endcode

    \subsection ss_sect Creation of Data Sources and Sinks

    Data sources and sinks are created in pairs.  Each source and
    each sink are then associated with their respective nodes, and
    connected to each other.  Parameters can be used to adjust the
    data coming from the data source.  The following example illustrates
    a typical simulation:
    \code
    traffic_source *sources[NUM_AGENTS];
    traffic_sink *sinks[NUM_AGENTS];

    for(i=0;i<NUM_AGENTS;i++)
    {
      sources[i] = new traffic_source;
      sinks[i] = new traffic_sink;

      // assign sources and sinks to random nodes, but make
      // sure they are at least MIN_DIST hops apart
      int sx,sy,dx,dy;
      do
        {
          sx = random() % MESHSIZE;
          sy = random() % MESHSIZE;
          dx = random() % MESHSIZE;
          dy = random() % MESHSIZE;
        }
      while(distance(sx,sy,dx,dy)<MIN_DIST);

      // attach source i to selected node
      sources[i]->set_node(nodes[sx][sy]);
      // attach sink i to selected node
      sinks[i]->set_node(nodes[dx][dy]);
      // tell source who it is sending to
      sources[i]->attach(sinks[i]);
      // tell sink who it is receiving from
      sinks[i]->attach(sources[i]);

      // Set the TTL for each packet
      sources[i]->set_ttl(PACKET_TTL);
      // Set size of each packet
      sources[i]->set_pkt_size(PACKET_SIZE);
      // send out a packets at this rate
      sources[i]->set_rate(PKT_PER_SEC);
      // start sending packets at START_TIME
      sources[i]->start_at(START_TIME);
      // stop sending at STOP_TIME
      sources[i]->stop_at(STOP_TIME);
    }
    \endcode

    \subsection rs_sect Running the Simulator

    After the nodes and links are configured, we can finish the
    initialization and start the simulation loop.  The Scheduler dispatch()
    method is used to process one event from the queue.  It returns 1 if
    there are more events to be processed, or if the current simulation time
    is less that the time set by Scheduler stop_at().
    The following
    code shows a typical sequence:    
    \code
    // call the start methods for all sim_objects that have been created
    sim_object::start_objects();

    // set the stop time for the simulation
    Scheduler.stop_at(SIM_END_TIME);

    // Start the simulation... Handle events while they exist,
    // or until time runs out
    while(Scheduler.dispatch())
      {
        // Any code inserted here will be run after every event
        // is processed.  This allows you to print status information
        // periodically, or adjust link and node parameters during
        // the simulation run.
      };
    \endcode

    \subsection tc_sect Termination and Clean-up

    When the Scheduler.dispatch() method returns 0, the simulation
    is complete and the event loop ends.  Now we only need to clean
    up and print any status information that we desire.  There are some
    object methods that we can call to get information about how many
    data packets were sent and received.  Here is a simple example:
    \code
    // count up all of our packets sent and received
    int sent = 0;
    int received = 0;
    for(int i=0;i<NUM_AGENTS;i++)
      {
        sent += sources[i]->packet_count();
        received += sinks[i]->packet_count();
      }

    // delete everything...
    sim_object::deleteall();
    Scheduler.flush();
    \endcode

    \section ad_sect Additional Examples

    There are some complete code examples in the examples directory
    included in the ADPnetsim distribution.  Be sure to look at those
    for more information.

 */

#include <iostream>
using namespace std;

class event;

/// Base class for objects that are part of the simulator.
///
/// The sim_object class is the base class for all objects
/// that are part of the simulator.  The sim_object class
/// provides mechanisms for managing all of the objects,
/// regardless of their derived class.  All objects derived
/// from sim_object are stored on a linked list.  When the
/// simulation begins, the linked list is traversed and the
/// start() method of all simulator objects is called.  After
/// simulation ends, the deletall() method can be used to
/// delete all simulator objects.  The programmer
/// who sets up the simulation does not need to keep track
/// of all of the simulator objects.  Once an object is created
/// and configured, the programmer can forget about it and
/// it will be handled by the simulator.
class sim_object{
 private:
  static sim_object *sim_objects;  ///< Linked list of all sim_objects
  static int last_ID;              ///< Last sim_object ID used
  int ID;                          ///< Unique ID for this Object
  sim_object *next;                ///< Next object on the linked list
 public:
  sim_object();
  virtual ~sim_object();  
  virtual void dump();           ///< Print info about this object to cout
  virtual void start();          ///< Prepare to start simulation

  /// Handle an event.
  ///
  /// Each sim_object has a handle() method for handling events.
  /// Each event contains a pointer to the object that will
  /// handle it.  When an event reaches the front of the queue,
  /// the scheduler uses the pointer in the event to call the handle
  /// method, and passes a pointer to the object so that it can find
  /// the event it is handling.
  /// The object should process the event
  /// and either delete it, or put it back in the queue for some
  /// other sim_object to handle.
  virtual void handle(event *e); 

  int get_ID();  ///< Get the unique id for this sim_object.

  static void dump_objects();  ///< Call the dump() method for all sim_objects
  static void start_objects(); ///< Call the start() method for all sim_objects
  static void deleteall();     ///< Delete all sim_objects

};


#endif
