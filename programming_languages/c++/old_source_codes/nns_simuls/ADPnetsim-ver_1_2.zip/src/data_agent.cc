// -*- Mode: C++ -*-

#include <sim_object.h>
#include <node.h>
#include <packet.h>
#include <event.h>
#include <data_agent.h>
#include <scheduler.h>

static char* timer_msg="timer";
#define JITTER (drand48()-0.5)

#define DEFAULT_TTL 20

data_agent::data_agent()
{
  seqnum = 0;
  packet_ttl = DEFAULT_TTL;
}

data_agent::~data_agent()
{
}

void data_agent::set_ttl(int ttl)
{
  packet_ttl = ttl;
}

void data_agent::handle(event *e)
{
}

void data_agent::dump()
{
}

void data_agent::start()
{
}

void data_agent::attach(data_agent *other_end)
{
  other = other_end;
}

void data_agent::set_port(int port)
{
  portnum = port;
}

int data_agent::get_port()
{
  return portnum;
}

void data_agent::set_node(node *n)
{
  Node = n;
  set_port(Node->install_agent(this));
  
}
node* data_agent::get_node()
{
  return Node;
}

addr_t data_agent::get_address()
{
  return Node->get_address();
}

packet_header *data_agent::make_header()
{
  packet_header *h = new packet_header;
  h->dst_addr = other->get_address();
  h->dst_port = other->get_port();
  h->src_addr = get_address();
  h->src_port = portnum;
  h->last_hop = get_address();
  h->seqnum = seqnum++;
  h->type = data;
  h->ttl = packet_ttl;
  h->hopcount = 0;
  return h;
}

traffic_source::traffic_source()
{
}

traffic_source::~traffic_source()
{
}

void traffic_source::start()
{
  // schedule a timer message event to send first packet at start_time+JITTER
  double s = start_time+(start_time * 0.1 * JITTER);
  if(s<0.0)
    s = 0.0;
  Scheduler.schedule(s, this, timer_msg);  
}

void traffic_source::dump()
{
  cout<<"traffic_source::dump() called.  All it does is print this message.";
  // nothing to dump 
}

void traffic_source::set_pkt_size(int size)
{
  packet_size = size;
}

void traffic_source::set_rate(double pkts_per_sec)
{
  packet_rate = pkts_per_sec;
}

void traffic_source::start_at(double tm)
{
  start_time = tm;
}

void traffic_source::stop_at(double tm)
{
  stop_time = tm;
}

/// Send a packet.
///
/// This method creates a data packet and encapsulates it in a
/// packet_event.  The packet event handler is set to the local
/// routing agent, which will read the destination of the packet
/// and schedule the packet to be sent on the appropriate link.
void traffic_source::send_packet()
{
  // construct the packet
  Packet *p = new Packet;
  packet_header *h = make_header();
  p->set_header(h);
  delete h;
  p->set_fake_payload(packet_size);
  
  // make a packet event to send packet to our node, which will send
  // it to the routing agent.
  packet_event *pe = new packet_event(Scheduler.time(),get_node());
  pe->set_packet(p);
  Scheduler.schedule(pe);
}

/// Process a message event
///
/// At the beginning of simulation, each traffic source sends itself a
/// message event, with the event time set for some time in the
/// future.  When that event is received, it sends another packet and
/// schedules another message event for itself.  Thus, the timing for
/// data packets is managed through the event queue.
void traffic_source::process_message(message_event *e)
{
  double s;
  if(strcmp(e->get_message(),timer_msg)==0)
    {
#ifdef DEBUG
      cout<<Scheduler.time()<<" traffic source on node "<<
	get_address()<< " port "<< get_port() <<" sending packet\n";
#endif
      send_packet();
      s = Scheduler.time()+1.0/packet_rate+(1.0/packet_rate) * 0.1 * JITTER;
      if(s<stop_time)
	Scheduler.schedule(s,this,timer_msg);
    }
  delete e;
}

/// Handle an event.
///
/// Traffic sources should only receive message events.  The handle
/// method just checks the event type and passes the message on to
/// process_message().
void traffic_source::handle(event *e)
{
    switch(e->type())
    {
    case event::packet:
      cerr<<"Traffic source event handler called with packet event type\n";
      break;
    case event::message:
      process_message((message_event *)e);
      break;
    case event::link:
      cerr<<"Traffic source event handler called with link event type\n";
      break;
    default:
      cerr<<"Link event handler called with bad event type\n";
      exit(1);
    }
}


/// Handle an event.
///
/// Traffic sinks should only receive packet events.  The handle
/// method just keeps track of how many packets have been received,
/// and deletes the event.
void traffic_sink::handle(event *e)
{
  packet_event *pe = (packet_event *)e;
  Packet *p = pe->get_packet();
  packet_header *h = p->get_header();

#ifdef DEBUG
  cout<<"sink received a packet from address "<<h->src_addr<<" port "<<
    h->dst_addr<<" seqnum="<<h->seqnum<<endl;
#endif
  // I should make sure it comes from MY source, and check for other
  // problems, but I'm too busy to write that right now.
  seqnum++;
  delete e;
}

void traffic_sink::dump()
{

}

void traffic_sink::start()
{

}

