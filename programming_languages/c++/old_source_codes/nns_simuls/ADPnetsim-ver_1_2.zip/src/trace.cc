
#include <trace.h>

Trace trace;


